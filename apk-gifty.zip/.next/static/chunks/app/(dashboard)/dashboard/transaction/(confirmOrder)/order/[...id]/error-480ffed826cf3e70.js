(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[482],{3309:function(e,r,n){Promise.resolve().then(n.bind(n,981))},981:function(e,r,n){"use strict";n.r(r);var t=n(3955);n(2310),r.default=e=>{let{error:r,reset:n}=e;return(0,t.jsx)("div",{children:(0,t.jsx)("h2",{children:"There’s no order"})})}},3009:function(e,r,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2310),o=Symbol.for("react.element"),s=Symbol.for("react.fragment"),f=Object.prototype.hasOwnProperty,u=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,i={key:!0,ref:!0,__self:!0,__source:!0};function _(e,r,n){var t,s={},_=null,c=null;for(t in void 0!==n&&(_=""+n),void 0!==r.key&&(_=""+r.key),void 0!==r.ref&&(c=r.ref),r)f.call(r,t)&&!i.hasOwnProperty(t)&&(s[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===s[t]&&(s[t]=r[t]);return{$$typeof:o,type:e,key:_,ref:c,props:s,_owner:u.current}}r.Fragment=s,r.jsx=_,r.jsxs=_},3955:function(e,r,n){"use strict";e.exports=n(3009)}},function(e){e.O(0,[704,801,744],function(){return e(e.s=3309)}),_N_E=e.O()}]);