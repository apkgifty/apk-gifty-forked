exports.id = 6502;
exports.ids = [6502];
exports.modules = {

/***/ 78487:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23))

/***/ }),

/***/ 39621:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ settings_layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
;// CONCATENATED MODULE: ./components/Form/FormComponents/SettingsMenuItem.tsx

const SettingsMenuItem = ({ icon, title, subtitle, isSelected })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex gap-x-3 items-center cursor-pointer",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `w-12 h-12  rounded-lg flex justify-center items-center ${isSelected ? "bg-appviolet" : "bg-primary"}`,
                children: icon
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "font-bold",
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-400",
                        children: subtitle
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const FormComponents_SettingsMenuItem = (SettingsMenuItem);

// EXTERNAL MODULE: ./components/UI/SvgIcons/CurrencyIconSvg.tsx
var CurrencyIconSvg = __webpack_require__(84743);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/IntegrationsIconSvg.tsx


const IntegrationsIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Integrations-Icon",
                clipPath: "url(#clip0_502_1385)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M7.60495 8.78983C7.77841 9.42466 8.15575 9.98488 8.67885 10.3842C9.20196 10.7835 9.84184 10.9999 10.4999 10.9998H14.4999C15.678 10.9999 16.8182 11.4159 17.7195 12.1743C18.6209 12.9328 19.2255 13.9851 19.4269 15.1458C20.1056 15.3673 20.6832 15.8234 21.0558 16.4323C21.4285 17.0412 21.5719 17.7631 21.4602 18.4682C21.3486 19.1733 20.9892 19.8155 20.4466 20.2795C19.9041 20.7435 19.2139 20.9989 18.4999 20.9998C17.8015 21.0004 17.1247 20.7572 16.5863 20.3122C16.048 19.8672 15.6817 19.2483 15.5508 18.5622C15.4199 17.8761 15.5324 17.1659 15.8691 16.5539C16.2057 15.9419 16.7454 15.4666 17.3949 15.2098C17.2215 14.575 16.8441 14.0148 16.321 13.6154C15.7979 13.2161 15.1581 12.9998 14.4999 12.9998H10.4999C9.41784 13.0014 8.36468 12.6504 7.49995 11.9998V15.1698C8.16744 15.4057 8.73004 15.87 9.08831 16.4806C9.44657 17.0912 9.57743 17.8089 9.45776 18.5066C9.33808 19.2044 8.97558 19.8374 8.43432 20.2937C7.89306 20.75 7.2079 21.0003 6.49995 21.0003C5.79199 21.0003 5.10683 20.75 4.56557 20.2937C4.02431 19.8374 3.66181 19.2044 3.54213 18.5066C3.42246 17.8089 3.55332 17.0912 3.91159 16.4806C4.26985 15.87 4.83245 15.4057 5.49995 15.1698V8.82983C4.83692 8.59574 4.27715 8.13627 3.9183 7.53159C3.55945 6.92692 3.42432 6.21544 3.53648 5.52131C3.64864 4.82718 4.00098 4.19447 4.532 3.73359C5.06303 3.27271 5.73903 3.01292 6.44204 2.99957C7.14505 2.98621 7.83043 3.22012 8.37858 3.6605C8.92673 4.10087 9.30285 4.71974 9.4413 5.40911C9.57975 6.09848 9.47175 6.81457 9.13613 7.43244C8.80051 8.05031 8.2586 8.53072 7.60495 8.78983ZM6.49995 6.99983C6.76516 6.99983 7.01952 6.89447 7.20705 6.70693C7.39459 6.5194 7.49995 6.26504 7.49995 5.99983C7.49995 5.73461 7.39459 5.48026 7.20705 5.29272C7.01952 5.10518 6.76516 4.99983 6.49995 4.99983C6.23473 4.99983 5.98038 5.10518 5.79284 5.29272C5.6053 5.48026 5.49995 5.73461 5.49995 5.99983C5.49995 6.26504 5.6053 6.5194 5.79284 6.70693C5.98038 6.89447 6.23473 6.99983 6.49995 6.99983ZM6.49995 18.9998C6.76516 18.9998 7.01952 18.8945 7.20705 18.7069C7.39459 18.5194 7.49995 18.265 7.49995 17.9998C7.49995 17.7346 7.39459 17.4803 7.20705 17.2927C7.01952 17.1052 6.76516 16.9998 6.49995 16.9998C6.23473 16.9998 5.98038 17.1052 5.79284 17.2927C5.6053 17.4803 5.49995 17.7346 5.49995 17.9998C5.49995 18.265 5.6053 18.5194 5.79284 18.7069C5.98038 18.8945 6.23473 18.9998 6.49995 18.9998ZM18.4999 18.9998C18.7652 18.9998 19.0195 18.8945 19.2071 18.7069C19.3946 18.5194 19.4999 18.265 19.4999 17.9998C19.4999 17.7346 19.3946 17.4803 19.2071 17.2927C19.0195 17.1052 18.7652 16.9998 18.4999 16.9998C18.2347 16.9998 17.9804 17.1052 17.7928 17.2927C17.6053 17.4803 17.4999 17.7346 17.4999 17.9998C17.4999 18.265 17.6053 18.5194 17.7928 18.7069C17.9804 18.8945 18.2347 18.9998 18.4999 18.9998Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_1385",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_IntegrationsIconSvg = (IntegrationsIconSvg);

// EXTERNAL MODULE: ./components/UI/SvgIcons/KycIconSvg.tsx
var KycIconSvg = __webpack_require__(26860);
// EXTERNAL MODULE: ./components/UI/SvgIcons/NotificationSvg.tsx
var NotificationSvg = __webpack_require__(20350);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/PaymentIconSvg.tsx


const PaymentIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Payment-Icon",
                clipPath: "url(#clip0_502_1377)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M11.5 2L18.798 4.28C19.0015 4.34354 19.1794 4.47048 19.3057 4.64229C19.432 4.81409 19.5001 5.02177 19.5 5.235V7H21.5C21.7652 7 22.0196 7.10536 22.2071 7.29289C22.3946 7.48043 22.5 7.73478 22.5 8V16C22.5 16.2652 22.3946 16.5196 22.2071 16.7071C22.0196 16.8946 21.7652 17 21.5 17L18.28 17.001C17.893 17.511 17.423 17.961 16.88 18.331L11.5 22L6.12 18.332C5.31252 17.7815 4.65175 17.042 4.19514 16.1779C3.73853 15.3138 3.4999 14.3513 3.5 13.374V5.235C3.50012 5.02194 3.56829 4.81449 3.69456 4.64289C3.82084 4.47128 3.99862 4.34449 4.202 4.281L11.5 2ZM11.5 4.094L5.5 5.97V13.374C5.49986 13.9862 5.64025 14.5903 5.91036 15.1397C6.18048 15.6892 6.57311 16.1692 7.058 16.543L7.247 16.679L11.5 19.58L15.282 17H10.5C10.2348 17 9.98043 16.8946 9.79289 16.7071C9.60536 16.5196 9.5 16.2652 9.5 16V8C9.5 7.73478 9.60536 7.48043 9.79289 7.29289C9.98043 7.10536 10.2348 7 10.5 7H17.5V5.97L11.5 4.094ZM11.5 12V15H20.5V12H11.5ZM11.5 10H20.5V9H11.5V10Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_1377",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_PaymentIconSvg = (PaymentIconSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/SecurityIconSvg.tsx


const SecurityIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Security_Icon",
                clipPath: "url(#clip0_502_1353)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M4.283 2.826L12.5 1L20.717 2.826C20.9391 2.87536 21.1377 2.99897 21.28 3.1764C21.4224 3.35384 21.5 3.57452 21.5 3.802V13.789C21.4999 14.7767 21.256 15.7492 20.7899 16.62C20.3238 17.4908 19.6499 18.2331 18.828 18.781L12.5 23L6.172 18.781C5.35027 18.2332 4.67646 17.4911 4.21035 16.6205C3.74424 15.7498 3.50024 14.7776 3.5 13.79V3.802C3.50004 3.57452 3.57764 3.35384 3.71999 3.1764C3.86234 2.99897 4.06094 2.87536 4.283 2.826ZM5.5 4.604V13.789C5.50001 14.4475 5.66257 15.0957 5.97326 15.6763C6.28395 16.2568 6.73315 16.7517 7.281 17.117L12.5 20.597L17.719 17.117C18.2667 16.7518 18.7158 16.2571 19.0265 15.6767C19.3372 15.0964 19.4998 14.4483 19.5 13.79V4.604L12.5 3.05L5.5 4.604Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_1353",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_SecurityIconSvg = (SecurityIconSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/UserIconSvg.tsx


const UserIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "User-icon",
                clipPath: "url(#clip0_502_1345)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M4.283 2.826L12.5 1L20.717 2.826C20.9391 2.87536 21.1377 2.99897 21.28 3.1764C21.4224 3.35384 21.5 3.57452 21.5 3.802V13.789C21.4999 14.7767 21.256 15.7492 20.7899 16.62C20.3238 17.4908 19.6499 18.2331 18.828 18.781L12.5 23L6.172 18.781C5.35027 18.2332 4.67646 17.4911 4.21035 16.6205C3.74424 15.7498 3.50024 14.7776 3.5 13.79V3.802C3.50004 3.57452 3.57764 3.35384 3.71999 3.1764C3.86234 2.99897 4.06094 2.87536 4.283 2.826ZM5.5 4.604V13.789C5.50001 14.4475 5.66257 15.0957 5.97326 15.6763C6.28395 16.2568 6.73315 16.7517 7.281 17.117L12.5 20.597L17.719 17.117C18.2667 16.7518 18.7158 16.2571 19.0265 15.6767C19.3372 15.0964 19.4998 14.4483 19.5 13.79V4.604L12.5 3.05L5.5 4.604ZM12.5 11C11.837 11 11.2011 10.7366 10.7322 10.2678C10.2634 9.79893 10 9.16304 10 8.5C10 7.83696 10.2634 7.20107 10.7322 6.73223C11.2011 6.26339 11.837 6 12.5 6C13.163 6 13.7989 6.26339 14.2678 6.73223C14.7366 7.20107 15 7.83696 15 8.5C15 9.16304 14.7366 9.79893 14.2678 10.2678C13.7989 10.7366 13.163 11 12.5 11ZM8.027 16C8.14822 14.8984 8.67168 13.8803 9.49708 13.1407C10.3225 12.4012 11.3918 11.9922 12.5 11.9922C13.6082 11.9922 14.6775 12.4012 15.5029 13.1407C16.3283 13.8803 16.8518 14.8984 16.973 16H8.027Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_1345",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_UserIconSvg = (UserIconSvg);

// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(63919);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(78875);
;// CONCATENATED MODULE: ./app/(dashboard)/dashboard/settings/layout.tsx











const layout = ({ children })=>{
    const cookieStore = (0,headers.cookies)();
    const accessToken = cookieStore.get("access");
    if (accessToken === undefined) {
        return (0,navigation.redirect)("/login");
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full flex flex-col lg:flex-row ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden lg:flex flex-col w-full lg:w-[35%] text-white gap-y-8 px-8 pt-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Personal Information",
                        subtitle: "Profile Settings",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_UserIconSvg, {}),
                        isSelected: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Security",
                        subtitle: "For your account security",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_SecurityIconSvg, {}),
                        isSelected: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Currency preferences",
                        subtitle: "Choose currency",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(CurrencyIconSvg/* default */.Z, {}),
                        isSelected: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Notifications",
                        subtitle: "Application notification settings",
                        isSelected: false,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(NotificationSvg/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Payment Option",
                        subtitle: "Methods of buying gift cards",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_PaymentIconSvg, {}),
                        isSelected: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "Integrations",
                        subtitle: "Access to APIs and side programs",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_IntegrationsIconSvg, {}),
                        isSelected: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_SettingsMenuItem, {
                        title: "KYC Verification",
                        subtitle: "Authenticate your identity",
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(KycIconSvg/* default */.Z, {}),
                        isSelected: false
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-8  pt-10 w-full lg:w-[65%]",
                children: [
                    " ",
                    children
                ]
            })
        ]
    });
};
/* harmony default export */ const settings_layout = (layout);


/***/ }),

/***/ 84743:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35465);


const CurrencyIconSvg = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "Currency-Icon",
                clipPath: "url(#clip0_502_1361)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "Vector",
                    d: "M12.5 22C6.977 22 2.5 17.523 2.5 12C2.5 6.477 6.977 2 12.5 2C18.023 2 22.5 6.477 22.5 12C22.5 17.523 18.023 22 12.5 22ZM12.5 20C14.6217 20 16.6566 19.1571 18.1569 17.6569C19.6571 16.1566 20.5 14.1217 20.5 12C20.5 9.87827 19.6571 7.84344 18.1569 6.34315C16.6566 4.84285 14.6217 4 12.5 4C10.3783 4 8.34344 4.84285 6.84315 6.34315C5.34285 7.84344 4.5 9.87827 4.5 12C4.5 14.1217 5.34285 16.1566 6.84315 17.6569C8.34344 19.1571 10.3783 20 12.5 20ZM9 14H14.5C14.6326 14 14.7598 13.9473 14.8536 13.8536C14.9473 13.7598 15 13.6326 15 13.5C15 13.3674 14.9473 13.2402 14.8536 13.1464C14.7598 13.0527 14.6326 13 14.5 13H10.5C9.83696 13 9.20107 12.7366 8.73223 12.2678C8.26339 11.7989 8 11.163 8 10.5C8 9.83696 8.26339 9.20107 8.73223 8.73223C9.20107 8.26339 9.83696 8 10.5 8H11.5V6H13.5V8H16V10H10.5C10.3674 10 10.2402 10.0527 10.1464 10.1464C10.0527 10.2402 10 10.3674 10 10.5C10 10.6326 10.0527 10.7598 10.1464 10.8536C10.2402 10.9473 10.3674 11 10.5 11H14.5C15.163 11 15.7989 11.2634 16.2678 11.7322C16.7366 12.2011 17 12.837 17 13.5C17 14.163 16.7366 14.7989 16.2678 15.2678C15.7989 15.7366 15.163 16 14.5 16H13.5V18H11.5V16H9V14Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0_502_1361",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrencyIconSvg);


/***/ }),

/***/ 26860:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35465);


const KycIconSvg = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: 25,
        height: 24,
        viewBox: "0 0 25 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "User-Icon",
                clipPath: "url(#clip0_502_1393)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "Vector",
                    d: "M12.5 22C6.977 22 2.5 17.523 2.5 12C2.5 6.477 6.977 2 12.5 2C18.023 2 22.5 6.477 22.5 12C22.5 17.523 18.023 22 12.5 22ZM12.5 20C14.6217 20 16.6566 19.1571 18.1569 17.6569C19.6571 16.1566 20.5 14.1217 20.5 12C20.5 9.87827 19.6571 7.84344 18.1569 6.34315C16.6566 4.84285 14.6217 4 12.5 4C10.3783 4 8.34344 4.84285 6.84315 6.34315C5.34285 7.84344 4.5 9.87827 4.5 12C4.5 14.1217 5.34285 16.1566 6.84315 17.6569C8.34344 19.1571 10.3783 20 12.5 20ZM7.5 12H9.5C9.5 12.7956 9.81607 13.5587 10.3787 14.1213C10.9413 14.6839 11.7044 15 12.5 15C13.2956 15 14.0587 14.6839 14.6213 14.1213C15.1839 13.5587 15.5 12.7956 15.5 12H17.5C17.5 13.3261 16.9732 14.5979 16.0355 15.5355C15.0979 16.4732 13.8261 17 12.5 17C11.1739 17 9.90215 16.4732 8.96447 15.5355C8.02678 14.5979 7.5 13.3261 7.5 12Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0_502_1393",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KycIconSvg);


/***/ })

};
;