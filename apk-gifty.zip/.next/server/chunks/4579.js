exports.id = 4579;
exports.ids = [4579];
exports.modules = {

/***/ 83843:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_0ec1f4', '__Inter_Fallback_0ec1f4'","fontStyle":"normal"},
	"className": "__className_0ec1f4"
};


/***/ }),

/***/ 73962:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 43429));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63912, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23))

/***/ }),

/***/ 31713:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\(main)\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_main_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(83843);
var target_path_app_main_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_main_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(92817);
// EXTERNAL MODULE: ./components/Nav/Navbar.tsx + 1 modules
var Navbar = __webpack_require__(84094);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/Layout/AppLayout.tsx
var AppLayout = __webpack_require__(35311);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(34834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Main/Footer/FooterBlock.tsx



const FooterBlock = ({ headerTitle, items })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " flex flex-col text-center lg:text-left",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                className: "text-base font-semibold pb-2",
                children: headerTitle
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "space-y-1",
                children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "text-sm font-thin",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: item.url,
                            children: item.title
                        })
                    }, item.title))
            })
        ]
    });
};
/* harmony default export */ const Footer_FooterBlock = (FooterBlock);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/FooterCircleSvg.tsx


const FooterCircleSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 16,
        height: 16,
        viewBox: "0 0 16 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "bi:c-circle",
                clipPath: "url(#clip0_480_4167)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M1 8C1 9.85652 1.7375 11.637 3.05025 12.9497C4.36301 14.2625 6.14348 15 8 15C9.85652 15 11.637 14.2625 12.9497 12.9497C14.2625 11.637 15 9.85652 15 8C15 6.14348 14.2625 4.36301 12.9497 3.05025C11.637 1.7375 9.85652 1 8 1C6.14348 1 4.36301 1.7375 3.05025 3.05025C1.7375 4.36301 1 6.14348 1 8ZM16 8C16 10.1217 15.1571 12.1566 13.6569 13.6569C12.1566 15.1571 10.1217 16 8 16C5.87827 16 3.84344 15.1571 2.34315 13.6569C0.842855 12.1566 0 10.1217 0 8C0 5.87827 0.842855 3.84344 2.34315 2.34315C3.84344 0.842855 5.87827 0 8 0C10.1217 0 12.1566 0.842855 13.6569 2.34315C15.1571 3.84344 16 5.87827 16 8ZM8.146 4.992C6.934 4.992 6.219 5.912 6.219 7.494V8.554C6.219 10.125 6.922 11.016 8.146 11.016C9.125 11.016 9.787 10.43 9.875 9.598H11.17V9.691C11.07 11.139 9.816 12.158 8.14 12.158C6.049 12.158 4.871 10.822 4.871 8.555V7.482C4.871 5.221 6.072 3.844 8.141 3.844C9.822 3.844 11.076 4.898 11.17 6.416V6.504H9.875C9.787 5.625 9.107 4.992 8.146 4.992Z",
                    fill: "#70798B"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_480_4167",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 16,
                        height: 16,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_FooterCircleSvg = (FooterCircleSvg);

;// CONCATENATED MODULE: ./components/Main/Footer/PageFooter.tsx






const PageFooter = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-secondary py-12 text-white ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AppLayout/* default */.Z, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full flex flex-col gap-y-4 items-center justify-center  lg:flex-row lg:justify-between lg:gap-x-0 lg:items-start",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer_FooterBlock, {
                            headerTitle: "Support",
                            items: [
                                {
                                    title: "Create an Account",
                                    url: "/signup"
                                },
                                {
                                    title: "How to Buy Gift Cards",
                                    url: "#"
                                },
                                {
                                    title: "How to Sell Gift Cards",
                                    url: "#"
                                },
                                {
                                    title: "FAQ",
                                    url: "#"
                                },
                                {
                                    title: "Contact Us",
                                    url: "#"
                                }
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer_FooterBlock, {
                            headerTitle: "Company",
                            items: [
                                {
                                    title: "About",
                                    url: "/about"
                                },
                                {
                                    title: "Support",
                                    url: "#"
                                },
                                {
                                    title: "Buy",
                                    url: "/dashboard/exchange/buy"
                                },
                                {
                                    title: "Sell",
                                    url: "/dashboard/exchange/sell"
                                }
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer_FooterBlock, {
                            headerTitle: "Social",
                            items: [
                                {
                                    title: "Facebook",
                                    url: "#"
                                },
                                {
                                    title: "Twitter",
                                    url: "#"
                                },
                                {
                                    title: "Instagram",
                                    url: "#"
                                }
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Footer_FooterBlock, {
                            headerTitle: "Legal",
                            items: [
                                {
                                    title: "Terms & Conditions",
                                    url: "/terms-of-service"
                                },
                                {
                                    title: "Privacy Policy",
                                    url: "/privacy-policy"
                                }
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full flex flex-col items-center gap-y-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/images/apklogo-new.png",
                            width: 150,
                            height: 150,
                            alt: "apk logo"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-x-2 items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_FooterCircleSvg, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-[12px] text-gray-600",
                                    children: "2023 APKXCHANGE"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_PageFooter = (PageFooter);

;// CONCATENATED MODULE: ./app/(main)/layout.tsx





const metadata = {
    title: "APK Exchange",
    description: "Site to trade giftcards"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: `${(target_path_app_main_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className} bg-tertiary`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.Z, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full",
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Footer_PageFooter, {})
            ]
        })
    });
}


/***/ }),

/***/ 90273:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__  cjs */ 
const { createProxy } = __webpack_require__(21313);
module.exports = createProxy("C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\node_modules\\next\\dist\\client\\link.js");
 //# sourceMappingURL=link.js.map


/***/ }),

/***/ 34834:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(90273);


/***/ })

};
;