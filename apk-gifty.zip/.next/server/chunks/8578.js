"use strict";
exports.id = 8578;
exports.ids = [8578];
exports.modules = {

/***/ 28578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ FormComponents_Form)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/react-hook-form/dist/index.esm.mjs
var index_esm = __webpack_require__(71031);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./components/Form/FormComponents/FormInput.tsx
var FormInput = __webpack_require__(73874);
// EXTERNAL MODULE: ./components/Form/FormComponents/ButtonIcon.tsx + 1 modules
var ButtonIcon = __webpack_require__(95874);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/NextSvg.tsx


const NextSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 15,
        height: 15,
        viewBox: "0 0 15 15",
        fill: "none",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                clipPath: "url(#clip0_101_4549)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M1.10722 8.63995L10.7612 8.63996L6.99123 12.3799C6.77927 12.5975 6.66064 12.8892 6.66064 13.1929C6.66064 13.4967 6.77927 13.7884 6.99123 14.006C7.20591 14.218 7.49549 14.3369 7.79723 14.3369C8.09896 14.3369 8.38855 14.218 8.60323 14.006L14.3352 8.30597C14.5403 8.08788 14.6544 7.79983 14.6544 7.50049C14.6544 7.20115 14.5403 6.91304 14.3352 6.69495L8.60323 0.994936C8.38855 0.782905 8.09896 0.664064 7.79723 0.664064C7.49549 0.664064 7.20591 0.782905 6.99123 0.994935C6.78409 1.21066 6.66498 1.49601 6.65723 1.79498C6.66017 2.09673 6.77988 2.38557 6.99123 2.60095L10.7612 6.35596L1.10722 6.35596C0.810591 6.36474 0.52905 6.48873 0.322336 6.70166C0.115621 6.91459 1.24791e-06 7.1997 1.19602e-06 7.49646C1.14414e-06 7.79322 0.115621 8.07833 0.322335 8.29126C0.52905 8.50419 0.810591 8.62818 1.10722 8.63696L1.10722 8.63995Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4549",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: "14.4018",
                        height: "13.674",
                        fill: "white",
                        transform: "matrix(1 1.78296e-07 1.71461e-07 -1 0.0859375 14.3369)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_NextSvg = (NextSvg);

// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./node_modules/react-cookie/cjs/index.js
var cjs = __webpack_require__(15786);
;// CONCATENATED MODULE: ./hooks/useAuth.ts



const useAuth = ()=>{
    const [data, setData] = (0,react_experimental_.useState)(null);
    const [error, setError] = (0,react_experimental_.useState)(null);
    const [loading, setLoading] = (0,react_experimental_.useState)(false);
    const [cookies, setCookie] = (0,cjs.useCookies)([
        "access"
    ]);
    const submitRequest = async (payload, endpoint)=>{
        const config = {
            url: endpoint,
            data: payload,
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json"
            }
        };
        try {
            setLoading(true);
            const response = await (0,axios/* default */.Z)(config);
            console.log(response.data);
            if (data?.token) {
                setCookie("access", data.cookie);
            }
            localStorage.setItem("userInfo", JSON.stringify(response.data));
            setData(response.data);
        } catch (error) {
            setError(error.response.data);
        } finally{
            setLoading(false);
        }
    };
    return {
        data,
        loading,
        error,
        submitRequest
    };
};


// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(64085);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Form/FormComponents/Form.tsx










// interface Fields {
//   placeholder: string;
//   type: string;
//   icon: React.ReactNode;
//   name: string;
// }
const Form = ({ fields, redirectUrl, endpoint, afterSubmit })=>{
    const pathName = (0,navigation.usePathname)();
    const { register, handleSubmit, watch, formState: { errors } } = (0,index_esm/* useForm */.cI)();
    const { data, loading, error, submitRequest } = useAuth();
    const onSubmit = (data)=>submitRequest(data, endpoint);
    (0,react_experimental_.useEffect)(()=>{
        console.log(data);
        afterSubmit(data);
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                className: "flex flex-col gap-4",
                onSubmit: handleSubmit(onSubmit),
                children: [
                    fields.map((field)=>/*#__PURE__*/ jsx_runtime_.jsx(FormInput["default"], {
                            placeholder: field.placeholder,
                            type: field.type,
                            icon: field.icon,
                            name: field.name,
                            config: field.config,
                            register: register,
                            errors: errors,
                            className: "bg-tertiary"
                        }, field.name)),
                    pathName === "/signup" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                id: "link-checkbox",
                                type: "checkbox",
                                defaultValue: "",
                                className: "w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500   focus:ring-2  ",
                                ...register("agree", {
                                    required: false
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                htmlFor: "link-checkbox",
                                className: "ml-2 text-sm font-medium text-white",
                                children: [
                                    "I agree to the",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                        href: "/terms-of-service",
                                        className: "text-blue-600  hover:underline",
                                        children: [
                                            " ",
                                            "Terms and Conditions"
                                        ]
                                    }),
                                    "."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ButtonIcon/* default */.Z, {
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_NextSvg, {}),
                        type: "submit",
                        loading: loading
                    })
                ]
            }),
            error && /*#__PURE__*/ jsx_runtime_.jsx(node.Snackbar, {
                open: error === null ? false : true,
                autoHideDuration: 6000,
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "right"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(node.Alert, {
                    severity: "error",
                    children: error?.message
                })
            })
        ]
    });
};
/* harmony default export */ const FormComponents_Form = (Form);


/***/ })

};
;