exports.id = 4057;
exports.ids = [4057];
exports.modules = {

/***/ 64339:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63912, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10192));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 50755))

/***/ }),

/***/ 10192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Filter_FilterSelectOutline)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/DropIcon.tsx


const DropIcon = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 16,
        height: 16,
        viewBox: "0 0 16 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "Frame",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                id: "Vector",
                d: "M11 5.66016V7.16016L8 10.3402L5 7.16016V5.66016H11Z",
                fill: "#707A8A"
            })
        })
    });
};
/* harmony default export */ const SvgIcons_DropIcon = (DropIcon);

;// CONCATENATED MODULE: ./components/Filter/FilterSelectOutline.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const FilterSelectOutline = ({ label, icon, options, border, borderColor })=>{
    const [selectedOption, setSelectedOption] = (0,react_experimental_.useState)(()=>{
        return options[0];
    });
    const [showOptions, setShowOptions] = (0,react_experimental_.useState)(false);
    const componentRef = (0,react_experimental_.useRef)(null);
    (0,react_experimental_.useEffect)(()=>{
        const handleClickOutside = (event)=>{
            if (componentRef.current && !componentRef.current.contains(event.target)) {
                setShowOptions(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "space-y-1 relative",
        ref: componentRef,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "text-xs  text-gray-300 ",
                children: label
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full  px-2 py-2 bg-tertiary flex items-center gap-x-2 rounded-lg hover:cursor-pointer  border-2 border-gray-700",
                onClick: ()=>{
                    setShowOptions(!showOptions);
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: icon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-white text-xs flex-shrink-0 max-w-[4rem] min-w-[4rem] whitespace-nowrap overflow-hidden overflow-ellipsis ",
                        children: selectedOption !== "" ? selectedOption : "All Regions"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-gray-600 text-xs",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_DropIcon, {})
                    })
                ]
            }),
            showOptions && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute top-13  bg-secondary w-36 flex rounded-sm shadow",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "w-full text-xs cursor-pointer ",
                    children: options.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "hover:bg-tertiary w-full px-2 py-3 border-b border-zinc-700",
                            onClick: ()=>{
                                setSelectedOption(option);
                                setShowOptions(false);
                            },
                            children: option
                        }, option))
                })
            })
        ]
    });
};
/* harmony default export */ const Filter_FilterSelectOutline = (FilterSelectOutline);


/***/ }),

/***/ 34483:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_3__);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Product = ({ // title,
// price,
// category,
// iconUrl,
// imageUrl,
productInfo })=>{
    const { name, price, category, icon, image_url } = productInfo;
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_3__.usePathname)();
    const splitPathname = pathname.split("/");
    const pathTag = splitPathname[splitPathname.length - 1];
    // Add pid to params so it can be picked from url
    const prod = {
        ...productInfo,
        pid: productInfo.id
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full lg:w-[300px] ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
            href: {
                pathname: `/dashboard/exchange/product/${pathTag}`,
                query: prod
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: image_url,
                    alt: "apple card",
                    width: 0,
                    height: 0,
                    className: "w-full h-auto"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between border-b border-gray-600 py-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-white text-sm",
                            children: name
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            className: "text-green-400 text-xs px-1 py-1 border-2 border-green-400 rounded-sm",
                            children: [
                                "$",
                                price
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "py-2 flex justify-between items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/apple.svg",
                                    width: 20
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xs text-white",
                                    children: "Walmart"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-white text-xs",
                                children: [
                                    "Qty: ",
                                    productInfo.quantity
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Product);


/***/ }),

/***/ 67181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _listing_layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/Card/Card.tsx
var Card = __webpack_require__(7327);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Form/FormComponents/Switch.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Form\FormComponents\Switch.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Switch = (__default__);
;// CONCATENATED MODULE: ./components/Filter/FilterSelectOutline.tsx

const FilterSelectOutline_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Filter\FilterSelectOutline.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: FilterSelectOutline_esModule, $$typeof: FilterSelectOutline_$$typeof } = FilterSelectOutline_proxy;
const FilterSelectOutline_default_ = FilterSelectOutline_proxy.default;


/* harmony default export */ const FilterSelectOutline = (FilterSelectOutline_default_);
;// CONCATENATED MODULE: ./app/(dashboard)/dashboard/exchange/(listing)/layout.tsx





const layout = ({ children })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "px-2 mb-32  lg:mb:0",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card/* default */.Z, {
                className: "bg-secondary justify-center items-center flex flex-col pb-8 w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/images/image 9.png",
                            width: 120,
                            alt: "gift card",
                            height: 150
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-2xl font-bold",
                        children: "Gift card collection"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm text-gray-500",
                        children: "APKexchange.com, Trade anything anywhere with APKexchange.com!"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full lg:max-w-[1150px] m-auto",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full text-white flex justify-center mt-4",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Switch, {
                            items: [
                                {
                                    label: "Buy Gift Cards",
                                    url: "buy"
                                },
                                {
                                    label: "Sell Gift Cards",
                                    url: "sell"
                                }
                            ],
                            backgroundColor: "bg-secondary"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-center items-center gap-x-4 mt-3 py-6 border-b border-gray-700",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "py-2 px-3 bg-secondary rounded-lg text-white text-xs hover:cursor-pointer",
                                children: "All Products"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-gray-500 text-xs hover:cursor-pointer",
                                children: "Amazon"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-gray-500 text-xs hover:cursor-pointer",
                                children: "ITunes"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-gray-500 text-xs hover:cursor-pointer",
                                children: "Walmart"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-x-4 justify-center text-white mt-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(FilterSelectOutline, {
                                label: "Category",
                                options: [
                                    "Shopping",
                                    "Food",
                                    "Clothing"
                                ],
                                border: true,
                                borderColor: "border-gray-500"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FilterSelectOutline, {
                                label: "Tags",
                                options: [
                                    "GiftCards",
                                    "Food",
                                    "Clothing"
                                ],
                                border: true,
                                borderColor: "border-gray-500"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FilterSelectOutline, {
                                label: "Gift Cards",
                                options: [
                                    "GiftCards",
                                    "Food",
                                    "Clothing"
                                ],
                                border: true,
                                borderColor: "border-gray-500"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pb-32 lg:pb-10",
                        children: children
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const _listing_layout = (layout);


/***/ }),

/***/ 18935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Product\Product.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;