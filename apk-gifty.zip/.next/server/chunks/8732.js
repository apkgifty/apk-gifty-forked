exports.id = 8732;
exports.ids = [8732];
exports.modules = {

/***/ 24732:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3280, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 69274, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3349, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90701, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74654));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7538));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 95275));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63912, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 74816))

/***/ }),

/***/ 74654:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(82314);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const ScaleAnimate = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion */ .E.div, {
        whileHover: {
            scale: 1.2,
            transition: {
                duration: 0.3,
                delay: 0
            }
        },
        whileTap: {
            scale: 0.8,
            transition: {
                duration: 0.2,
                delay: 0
            }
        },
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ScaleAnimate);


/***/ }),

/***/ 7538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Sidebar_Sidebar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/DashboardSvg.tsx

const DashboardSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Dashboard-Icon",
                clipPath: "url(#clip0_101_4111)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M6.5 11.5C5.90905 11.5 5.32389 11.3836 4.77792 11.1575C4.23196 10.9313 3.73588 10.5998 3.31802 10.182C2.90016 9.76412 2.56869 9.26804 2.34254 8.72208C2.1164 8.17611 2 7.59095 2 7C2 6.40905 2.1164 5.82389 2.34254 5.27792C2.56869 4.73196 2.90016 4.23588 3.31802 3.81802C3.73588 3.40016 4.23196 3.06869 4.77792 2.84254C5.32389 2.6164 5.90905 2.5 6.5 2.5C7.69347 2.5 8.83807 2.97411 9.68198 3.81802C10.5259 4.66193 11 5.80653 11 7C11 8.19347 10.5259 9.33807 9.68198 10.182C8.83807 11.0259 7.69347 11.5 6.5 11.5V11.5ZM7 21.5C5.80653 21.5 4.66193 21.0259 3.81802 20.182C2.97411 19.3381 2.5 18.1935 2.5 17C2.5 15.8065 2.97411 14.6619 3.81802 13.818C4.66193 12.9741 5.80653 12.5 7 12.5C8.19347 12.5 9.33807 12.9741 10.182 13.818C11.0259 14.6619 11.5 15.8065 11.5 17C11.5 18.1935 11.0259 19.3381 10.182 20.182C9.33807 21.0259 8.19347 21.5 7 21.5V21.5ZM17 11.5C16.4091 11.5 15.8239 11.3836 15.2779 11.1575C14.732 10.9313 14.2359 10.5998 13.818 10.182C13.4002 9.76412 13.0687 9.26804 12.8425 8.72208C12.6164 8.17611 12.5 7.59095 12.5 7C12.5 6.40905 12.6164 5.82389 12.8425 5.27792C13.0687 4.73196 13.4002 4.23588 13.818 3.81802C14.2359 3.40016 14.732 3.06869 15.2779 2.84254C15.8239 2.6164 16.4091 2.5 17 2.5C18.1935 2.5 19.3381 2.97411 20.182 3.81802C21.0259 4.66193 21.5 5.80653 21.5 7C21.5 8.19347 21.0259 9.33807 20.182 10.182C19.3381 11.0259 18.1935 11.5 17 11.5V11.5ZM17 21.5C15.8065 21.5 14.6619 21.0259 13.818 20.182C12.9741 19.3381 12.5 18.1935 12.5 17C12.5 15.8065 12.9741 14.6619 13.818 13.818C14.6619 12.9741 15.8065 12.5 17 12.5C18.1935 12.5 19.3381 12.9741 20.182 13.818C21.0259 14.6619 21.5 15.8065 21.5 17C21.5 18.1935 21.0259 19.3381 20.182 20.182C19.3381 21.0259 18.1935 21.5 17 21.5ZM6.5 9.5C7.16304 9.5 7.79893 9.23661 8.26777 8.76777C8.73661 8.29893 9 7.66304 9 7C9 6.33696 8.73661 5.70107 8.26777 5.23223C7.79893 4.76339 7.16304 4.5 6.5 4.5C5.83696 4.5 5.20107 4.76339 4.73223 5.23223C4.26339 5.70107 4 6.33696 4 7C4 7.66304 4.26339 8.29893 4.73223 8.76777C5.20107 9.23661 5.83696 9.5 6.5 9.5V9.5ZM7 19.5C7.66304 19.5 8.29893 19.2366 8.76777 18.7678C9.23661 18.2989 9.5 17.663 9.5 17C9.5 16.337 9.23661 15.7011 8.76777 15.2322C8.29893 14.7634 7.66304 14.5 7 14.5C6.33696 14.5 5.70107 14.7634 5.23223 15.2322C4.76339 15.7011 4.5 16.337 4.5 17C4.5 17.663 4.76339 18.2989 5.23223 18.7678C5.70107 19.2366 6.33696 19.5 7 19.5ZM17 9.5C17.663 9.5 18.2989 9.23661 18.7678 8.76777C19.2366 8.29893 19.5 7.66304 19.5 7C19.5 6.33696 19.2366 5.70107 18.7678 5.23223C18.2989 4.76339 17.663 4.5 17 4.5C16.337 4.5 15.7011 4.76339 15.2322 5.23223C14.7634 5.70107 14.5 6.33696 14.5 7C14.5 7.66304 14.7634 8.29893 15.2322 8.76777C15.7011 9.23661 16.337 9.5 17 9.5ZM17 19.5C17.663 19.5 18.2989 19.2366 18.7678 18.7678C19.2366 18.2989 19.5 17.663 19.5 17C19.5 16.337 19.2366 15.7011 18.7678 15.2322C18.2989 14.7634 17.663 14.5 17 14.5C16.337 14.5 15.7011 14.7634 15.2322 15.2322C14.7634 15.7011 14.5 16.337 14.5 17C14.5 17.663 14.7634 18.2989 15.2322 18.7678C15.7011 19.2366 16.337 19.5 17 19.5Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4111",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_DashboardSvg = (DashboardSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/ExchangeSvg.tsx

const ExchangeSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Exchange-Icon",
                clipPath: "url(#clip0_101_4117)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22ZM12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20V20ZM7 13H16V15H12V18L7 13ZM12 9V6L17 11H8V9H12Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4117",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_ExchangeSvg = (ExchangeSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/NewsSvg.tsx

const NewsSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "News-Icon",
                clipPath: "url(#clip0_101_4106)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M19 22H5C4.20435 22 3.44129 21.6839 2.87868 21.1213C2.31607 20.5587 2 19.7956 2 19V3C2 2.73478 2.10536 2.48043 2.29289 2.29289C2.48043 2.10536 2.73478 2 3 2H17C17.2652 2 17.5196 2.10536 17.7071 2.29289C17.8946 2.48043 18 2.73478 18 3V15H22V19C22 19.7956 21.6839 20.5587 21.1213 21.1213C20.5587 21.6839 19.7956 22 19 22ZM18 17V19C18 19.2652 18.1054 19.5196 18.2929 19.7071C18.4804 19.8946 18.7348 20 19 20C19.2652 20 19.5196 19.8946 19.7071 19.7071C19.8946 19.5196 20 19.2652 20 19V17H18ZM16 20V4H4V19C4 19.2652 4.10536 19.5196 4.29289 19.7071C4.48043 19.8946 4.73478 20 5 20H16ZM6 7H14V9H6V7ZM6 11H14V13H6V11ZM6 15H11V17H6V15Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4106",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_NewsSvg = (NewsSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/SettingsSvg.tsx

const SettingsSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Settings-Icon",
                clipPath: "url(#clip0_101_4100)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M3.33933 16.9998C2.9166 16.2688 2.58799 15.4873 2.36133 14.6738C2.85464 14.4229 3.26892 14.0404 3.55836 13.5687C3.84779 13.097 4.00109 12.5544 4.0013 12.0009C4.00151 11.4475 3.84861 10.9048 3.55953 10.4328C3.27045 9.96088 2.85645 9.57809 2.36333 9.32682C2.81536 7.69231 3.67606 6.19977 4.86433 4.98982C5.32842 5.29155 5.86695 5.45898 6.42031 5.4736C6.97367 5.48822 7.52028 5.34945 7.99966 5.07265C8.47904 4.79586 8.87248 4.39182 9.13646 3.90526C9.40043 3.41871 9.52463 2.8686 9.49533 2.31582C11.1374 1.89145 12.8606 1.89213 14.5023 2.31782C14.4733 2.87059 14.5977 3.42061 14.8619 3.90703C15.1261 4.39345 15.5197 4.7973 15.9992 5.07388C16.4786 5.35047 17.0253 5.48901 17.5786 5.47417C18.1319 5.45934 18.6704 5.2917 19.1343 4.98982C19.7133 5.57982 20.2273 6.25082 20.6593 6.99982C21.0923 7.74882 21.4163 8.52982 21.6373 9.32582C21.144 9.57672 20.7297 9.9592 20.4403 10.4309C20.1509 10.9027 19.9976 11.4453 19.9974 11.9987C19.9971 12.5522 20.15 13.0949 20.4391 13.5668C20.7282 14.0388 21.1422 14.4216 21.6353 14.6728C21.1833 16.3073 20.3226 17.7999 19.1343 19.0098C18.6702 18.7081 18.1317 18.5407 17.5784 18.526C17.025 18.5114 16.4784 18.6502 15.999 18.927C15.5196 19.2038 15.1262 19.6078 14.8622 20.0944C14.5982 20.5809 14.474 21.131 14.5033 21.6838C12.8612 22.1082 11.1381 22.1075 9.49633 21.6818C9.52537 21.1291 9.40093 20.579 9.13675 20.0926C8.87257 19.6062 8.47897 19.2023 7.9995 18.9258C7.52003 18.6492 6.97338 18.5106 6.42005 18.5255C5.86673 18.5403 5.32829 18.7079 4.86433 19.0098C4.27332 18.4068 3.76092 17.7314 3.33933 16.9998V16.9998ZM8.99933 17.1958C10.065 17.8105 10.8662 18.7968 11.2493 19.9658C11.7483 20.0128 12.2493 20.0138 12.7483 19.9668C13.1317 18.7977 13.9333 17.8113 14.9993 17.1968C16.0645 16.5805 17.3199 16.3793 18.5243 16.6318C18.8143 16.2238 19.0643 15.7888 19.2723 15.3338C18.4518 14.4173 17.9984 13.23 17.9993 11.9998C17.9993 10.7398 18.4693 9.56282 19.2723 8.66582C19.0629 8.21097 18.8118 7.77646 18.5223 7.36782C17.3186 7.62013 16.0641 7.4193 14.9993 6.80382C13.9337 6.18919 13.1325 5.20281 12.7493 4.03382C12.2503 3.98682 11.7493 3.98582 11.2503 4.03282C10.8669 5.20197 10.0653 6.18838 8.99933 6.80282C7.93411 7.41914 6.67881 7.62034 5.47433 7.36782C5.18489 7.77611 4.93446 8.21069 4.72633 8.66582C5.5469 9.58238 6.00021 10.7696 5.99933 11.9998C5.99933 13.2598 5.52933 14.4368 4.72633 15.3338C4.9358 15.7887 5.18687 16.2232 5.47633 16.6318C6.68005 16.3795 7.93454 16.5803 8.99933 17.1958ZM11.9993 14.9998C11.2037 14.9998 10.4406 14.6838 9.87801 14.1211C9.3154 13.5585 8.99933 12.7955 8.99933 11.9998C8.99933 11.2042 9.3154 10.4411 9.87801 9.8785C10.4406 9.31589 11.2037 8.99982 11.9993 8.99982C12.795 8.99982 13.558 9.31589 14.1206 9.8785C14.6833 10.4411 14.9993 11.2042 14.9993 11.9998C14.9993 12.7955 14.6833 13.5585 14.1206 14.1211C13.558 14.6838 12.795 14.9998 11.9993 14.9998ZM11.9993 12.9998C12.2645 12.9998 12.5189 12.8945 12.7064 12.7069C12.894 12.5194 12.9993 12.265 12.9993 11.9998C12.9993 11.7346 12.894 11.4803 12.7064 11.2927C12.5189 11.1052 12.2645 10.9998 11.9993 10.9998C11.7341 10.9998 11.4798 11.1052 11.2922 11.2927C11.1047 11.4803 10.9993 11.7346 10.9993 11.9998C10.9993 12.265 11.1047 12.5194 11.2922 12.7069C11.4798 12.8945 11.7341 12.9998 11.9993 12.9998V12.9998Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4100",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_SettingsSvg = (SettingsSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/TransactionSvg.tsx

const TransactionSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Transaction-Icon",
                clipPath: "url(#clip0_101_4153)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M19.3741 15.103C20.0229 13.5613 20.1723 11.855 19.8011 10.224C19.43 8.59303 18.557 7.11938 17.305 6.01024C16.0529 4.9011 14.4847 4.21225 12.8209 4.04055C11.1571 3.86884 9.48124 4.22292 8.02906 5.05299L7.03706 3.31599C8.5547 2.4486 10.2733 1.99435 12.0213 1.99856C13.7693 2.00278 15.4856 2.4653 16.9991 3.33999C21.4891 5.93199 23.2091 11.482 21.1161 16.11L22.4581 16.884L18.2931 19.098L18.1281 14.384L19.3741 15.103V15.103ZM4.62406 8.89699C3.97521 10.4387 3.82585 12.145 4.19698 13.776C4.56811 15.4069 5.44108 16.8806 6.69314 17.9897C7.9452 19.0989 9.51338 19.7877 11.1772 19.9594C12.8411 20.1311 14.5169 19.7771 15.9691 18.947L16.9611 20.684C15.4434 21.5514 13.7249 22.0056 11.9769 22.0014C10.2288 21.9972 8.5125 21.5347 6.99906 20.66C2.50906 18.068 0.789062 12.518 2.88206 7.88999L1.53906 7.11699L5.70406 4.90299L5.86906 9.61699L4.62306 8.89799L4.62406 8.89699ZM13.4141 14.828L10.5831 12L7.75506 14.828L6.34106 13.414L10.5841 9.17199L13.4131 12L16.2421 9.17199L17.6561 10.586L13.4131 14.828H13.4141Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4153",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_TransactionSvg = (TransactionSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/WalletSvg.tsx

const WalletSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Wallet-Icon",
                clipPath: "url(#clip0_101_4122)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M18 7H21C21.2652 7 21.5196 7.10536 21.7071 7.29289C21.8946 7.48043 22 7.73478 22 8V20C22 20.2652 21.8946 20.5196 21.7071 20.7071C21.5196 20.8946 21.2652 21 21 21H3C2.73478 21 2.48043 20.8946 2.29289 20.7071C2.10536 20.5196 2 20.2652 2 20V4C2 3.73478 2.10536 3.48043 2.29289 3.29289C2.48043 3.10536 2.73478 3 3 3H18V7ZM4 9V19H20V9H4ZM4 5V7H16V5H4ZM15 13H18V15H15V13Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4122",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_WalletSvg = (WalletSvg);

;// CONCATENATED MODULE: ./components/UI/Badge.tsx

const Badge = ({ info })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "text-xs px-1.5 py-0.5 rounded-md bg-red-600 flex justify-center items-center",
        children: info
    });
};
/* harmony default export */ const UI_Badge = (Badge);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./components/Dashboard/Sidebar/SideNavItem.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const SideNavItem = ({ url, title, icon, badgeData })=>{
    const pathname = (0,navigation.usePathname)();
    console.log(pathname.split("/")[2]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
        className: `flex items-center px-3 py-2 ${pathname.split("/")[2] === title.toLowerCase() ? "bg-[#587bf2] text-white" : "bg-transparent text-[#C2C2C2]"}  transition-colors duration-300 transform rounded-lg dark:text-gray-300 hover:bg-[#587bf2] hover:text-white dark:hover:bg-gray-800 dark:hover:text-gray-200 `,
        href: url,
        children: [
            icon,
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "mx-2 text-sm font-medium",
                children: title
            }),
            badgeData && /*#__PURE__*/ jsx_runtime_.jsx(UI_Badge, {
                info: badgeData
            })
        ]
    });
};
/* harmony default export */ const Sidebar_SideNavItem = (SideNavItem);

;// CONCATENATED MODULE: ./components/Dashboard/Sidebar/SideNavItems.tsx








const links = [
    {
        title: "Dashboard",
        url: "/",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_DashboardSvg, {})
    },
    {
        title: "Exchange",
        url: "/dashboard/exchange/buy",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_ExchangeSvg, {})
    },
    {
        title: "Wallet",
        url: "#",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_WalletSvg, {})
    },
    {
        title: "Transaction",
        url: "#",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_TransactionSvg, {})
    },
    {
        title: "Settings",
        url: "/dashboard/settings/personal-information",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_SettingsSvg, {})
    },
    {
        title: "News",
        url: "#",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_NewsSvg, {})
    }
];
const SideNavItems = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: "-mx-3 space-y-3 ",
            children: links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx(Sidebar_SideNavItem, {
                    title: link.title,
                    url: link.url,
                    icon: link.icon
                }, link.url))
        })
    });
};
/* harmony default export */ const Sidebar_SideNavItems = (SideNavItems);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/VerifiedSvg.tsx


const VerifiedSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 15,
        height: 15,
        viewBox: "0 0 15 15",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Frame",
                clipPath: "url(#clip0_101_4158)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M9.73225 1.43768L7.39367 0.13916L5.05504 1.43768L2.4832 2.17314L1.74773 4.74499L0.449219 7.0836L1.74773 9.4222L2.4832 11.994L5.05504 12.7295L7.39367 14.028L9.73225 12.7295L12.3042 11.994L13.0396 9.4222L14.3381 7.0836L13.0396 4.74499L12.3042 2.17314L9.73225 1.43768ZM10.8012 5.54605C11.1026 5.19825 11.065 4.67195 10.7173 4.37053C10.3694 4.0691 9.84308 4.1067 9.54167 4.4545L6.56033 7.89454L5.24563 6.37757C4.9442 6.02978 4.41791 5.99219 4.07011 6.2936C3.72232 6.59503 3.68472 7.12133 3.98614 7.46912L5.93059 9.7127C6.08888 9.89537 6.31865 10.0003 6.56033 10.0003C6.80201 10.0003 7.03178 9.89537 7.19007 9.7127L10.8012 5.54605Z",
                    fill: "#0CAF60"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4158",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 15,
                        height: 15,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_VerifiedSvg = (VerifiedSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/InboxSvg.tsx

const InboxSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Chat-Icon",
                clipPath: "url(#clip0_101_4134)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M10 3H14C16.1217 3 18.1566 3.84285 19.6569 5.34315C21.1571 6.84344 22 8.87827 22 11C22 13.1217 21.1571 15.1566 19.6569 16.6569C18.1566 18.1571 16.1217 19 14 19V22.5C9 20.5 2 17.5 2 11C2 8.87827 2.84285 6.84344 4.34315 5.34315C5.84344 3.84285 7.87827 3 10 3V3ZM12 17H14C14.7879 17 15.5681 16.8448 16.2961 16.5433C17.0241 16.2417 17.6855 15.7998 18.2426 15.2426C18.7998 14.6855 19.2417 14.0241 19.5433 13.2961C19.8448 12.5681 20 11.7879 20 11C20 10.2121 19.8448 9.43185 19.5433 8.7039C19.2417 7.97595 18.7998 7.31451 18.2426 6.75736C17.6855 6.20021 17.0241 5.75825 16.2961 5.45672C15.5681 5.15519 14.7879 5 14 5H10C8.4087 5 6.88258 5.63214 5.75736 6.75736C4.63214 7.88258 4 9.4087 4 11C4 14.61 6.462 16.966 12 19.48V17Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4134",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_InboxSvg = (InboxSvg);

;// CONCATENATED MODULE: ./components/Dashboard/Sidebar/SecondaryNavs.tsx



const SecondaryNavs_links = [
    {
        title: "Inbox",
        url: "#",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_InboxSvg, {}),
        data: "8"
    }
];
const SecondaryNavs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex items-center justify-between",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "text-base font-light text-[#C2C2C2] ",
                    children: "Insights"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "mt-4 -mx-3 space-y-3 ",
                children: SecondaryNavs_links.map((link)=>/*#__PURE__*/ jsx_runtime_.jsx(Sidebar_SideNavItem, {
                        title: link.title,
                        url: link.url,
                        icon: link.icon,
                        badgeData: link.data
                    }, link.title))
            })
        ]
    });
};
/* harmony default export */ const Sidebar_SecondaryNavs = (SecondaryNavs);

;// CONCATENATED MODULE: ./components/Dashboard/Sidebar/Sidebar.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const Sidebar = ()=>{
    const [userInfo, setUserInfo] = (0,react_experimental_.useState)(null);
    (0,react_experimental_.useEffect)(()=>{
        const user = localStorage.getItem("userInfo");
        console.log(JSON.parse(user));
        setUserInfo(JSON.parse(user));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("aside", {
        className: "hidden  lg:flex flex-col w-64 h-screen py-8 overflow-y-auto bg-secondary  border-r rtl:border-r-0 rtl:border-l border-tertiary",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex justify-center items-center cursor-pointer gap-x-1 border-b border-[#161D26] pb-8",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: "#",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "w-auto h-7",
                            src: "/images/apklogo.png",
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-white text-xs",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            children: [
                                "APK ",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " XCHANGE"
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col  items-center gap-y-2 py-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        className: "object-cover w-16 h-16 rounded-lg",
                        src: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=faceare&facepad=3&w=688&h=688&q=100",
                        alt: ""
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-sm font-semibold text-white capitalize ",
                                children: userInfo?.user?.firstname
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-center items-center gap-x-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xs text-white font-light ",
                                        children: "Verified "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_VerifiedSvg, {})
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col justify-between flex-1  px-5 mt-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_SideNavItems, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar_SecondaryNavs, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const Sidebar_Sidebar = (Sidebar);


/***/ }),

/***/ 95275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Providers: () => (/* binding */ Providers),
  "default": () => (/* binding */ provider)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(10668);
;// CONCATENATED MODULE: ./redux/features/orderSlice.ts

const initialState = {
    status: "0",
    stop: null
};
const order = (0,redux_toolkit_cjs_production_min.createSlice)({
    name: "order",
    initialState,
    reducers: {
        updateStatus: (state, action)=>{
            state.status = action.payload;
        },
        updateStop: (state, action)=>{
            state.stop = action.payload;
        }
    }
});
const { updateStatus, updateStop } = order.actions;
/* harmony default export */ const orderSlice = (order.reducer);

;// CONCATENATED MODULE: ./redux/store.ts


const store = (0,redux_toolkit_cjs_production_min.configureStore)({
    reducer: {
        orderReducer: orderSlice
    },
    devTools: "production" !== "production"
});

// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(1560);
;// CONCATENATED MODULE: ./redux/provider.tsx
/* __next_internal_client_entry_do_not_use__ Providers,default auto */ 


const Providers = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(lib.Provider, {
        store: store,
        children: children
    });
};
/* harmony default export */ const provider = (Providers);


/***/ }),

/***/ 42981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\(dashboard)\\layout.tsx","import":"Inter","arguments":[{"subsets":["latin"]}],"variableName":"inter"}
var target_path_app_dashboard_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_ = __webpack_require__(14454);
var target_path_app_dashboard_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_dashboard_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Dashboard/Sidebar/Sidebar.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Dashboard\Sidebar\Sidebar.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Sidebar = (__default__);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(92817);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Animations/ScaleAnimate.tsx

const ScaleAnimate_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Animations\ScaleAnimate.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ScaleAnimate_esModule, $$typeof: ScaleAnimate_$$typeof } = ScaleAnimate_proxy;
const ScaleAnimate_default_ = ScaleAnimate_proxy.default;


/* harmony default export */ const ScaleAnimate = (ScaleAnimate_default_);
;// CONCATENATED MODULE: ./components/UI/Badge.tsx

const Badge = ({ info })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: "text-xs px-1.5 py-0.5 rounded-md bg-red-600 flex justify-center items-center",
        children: info
    });
};
/* harmony default export */ const UI_Badge = (Badge);

// EXTERNAL MODULE: ./components/Card/Card.tsx
var Card = __webpack_require__(7327);
;// CONCATENATED MODULE: ./components/Card/Iconcard.tsx




const Iconcard = ({ badgeData, icon, animate })=>{
    let component;
    if (animate) {
        component = /*#__PURE__*/ jsx_runtime_.jsx(Card/* default */.Z, {
            className: "bg-tertiary cursor-pointer inline-flex items-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full h-full relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: icon
                        }),
                        badgeData && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "absolute top-0 -mt-1.5 right-0 -mr-3.5 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(UI_Badge, {
                                info: badgeData
                            })
                        })
                    ]
                })
            })
        });
    } else {
        component = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card/* default */.Z, {
            className: "bg-tertiary cursor-pointer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: icon
                }),
                badgeData && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "absolute top-0 mt-1.5 right-0 mr-1.5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(UI_Badge, {
                        info: badgeData
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: component
    });
};
/* harmony default export */ const Card_Iconcard = (Iconcard);

;// CONCATENATED MODULE: ./components/UI/LanguageSelect.tsx

const LanguageSelect_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\UI\LanguageSelect.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: LanguageSelect_esModule, $$typeof: LanguageSelect_$$typeof } = LanguageSelect_proxy;
const LanguageSelect_default_ = LanguageSelect_proxy.default;


/* harmony default export */ const LanguageSelect = (LanguageSelect_default_);
// EXTERNAL MODULE: ./components/UI/SvgIcons/NotificationSvg.tsx
var NotificationSvg = __webpack_require__(20350);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/SettingsSvg.tsx

const SettingsSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Settings-Icon",
                clipPath: "url(#clip0_101_4100)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M3.33933 16.9998C2.9166 16.2688 2.58799 15.4873 2.36133 14.6738C2.85464 14.4229 3.26892 14.0404 3.55836 13.5687C3.84779 13.097 4.00109 12.5544 4.0013 12.0009C4.00151 11.4475 3.84861 10.9048 3.55953 10.4328C3.27045 9.96088 2.85645 9.57809 2.36333 9.32682C2.81536 7.69231 3.67606 6.19977 4.86433 4.98982C5.32842 5.29155 5.86695 5.45898 6.42031 5.4736C6.97367 5.48822 7.52028 5.34945 7.99966 5.07265C8.47904 4.79586 8.87248 4.39182 9.13646 3.90526C9.40043 3.41871 9.52463 2.8686 9.49533 2.31582C11.1374 1.89145 12.8606 1.89213 14.5023 2.31782C14.4733 2.87059 14.5977 3.42061 14.8619 3.90703C15.1261 4.39345 15.5197 4.7973 15.9992 5.07388C16.4786 5.35047 17.0253 5.48901 17.5786 5.47417C18.1319 5.45934 18.6704 5.2917 19.1343 4.98982C19.7133 5.57982 20.2273 6.25082 20.6593 6.99982C21.0923 7.74882 21.4163 8.52982 21.6373 9.32582C21.144 9.57672 20.7297 9.9592 20.4403 10.4309C20.1509 10.9027 19.9976 11.4453 19.9974 11.9987C19.9971 12.5522 20.15 13.0949 20.4391 13.5668C20.7282 14.0388 21.1422 14.4216 21.6353 14.6728C21.1833 16.3073 20.3226 17.7999 19.1343 19.0098C18.6702 18.7081 18.1317 18.5407 17.5784 18.526C17.025 18.5114 16.4784 18.6502 15.999 18.927C15.5196 19.2038 15.1262 19.6078 14.8622 20.0944C14.5982 20.5809 14.474 21.131 14.5033 21.6838C12.8612 22.1082 11.1381 22.1075 9.49633 21.6818C9.52537 21.1291 9.40093 20.579 9.13675 20.0926C8.87257 19.6062 8.47897 19.2023 7.9995 18.9258C7.52003 18.6492 6.97338 18.5106 6.42005 18.5255C5.86673 18.5403 5.32829 18.7079 4.86433 19.0098C4.27332 18.4068 3.76092 17.7314 3.33933 16.9998V16.9998ZM8.99933 17.1958C10.065 17.8105 10.8662 18.7968 11.2493 19.9658C11.7483 20.0128 12.2493 20.0138 12.7483 19.9668C13.1317 18.7977 13.9333 17.8113 14.9993 17.1968C16.0645 16.5805 17.3199 16.3793 18.5243 16.6318C18.8143 16.2238 19.0643 15.7888 19.2723 15.3338C18.4518 14.4173 17.9984 13.23 17.9993 11.9998C17.9993 10.7398 18.4693 9.56282 19.2723 8.66582C19.0629 8.21097 18.8118 7.77646 18.5223 7.36782C17.3186 7.62013 16.0641 7.4193 14.9993 6.80382C13.9337 6.18919 13.1325 5.20281 12.7493 4.03382C12.2503 3.98682 11.7493 3.98582 11.2503 4.03282C10.8669 5.20197 10.0653 6.18838 8.99933 6.80282C7.93411 7.41914 6.67881 7.62034 5.47433 7.36782C5.18489 7.77611 4.93446 8.21069 4.72633 8.66582C5.5469 9.58238 6.00021 10.7696 5.99933 11.9998C5.99933 13.2598 5.52933 14.4368 4.72633 15.3338C4.9358 15.7887 5.18687 16.2232 5.47633 16.6318C6.68005 16.3795 7.93454 16.5803 8.99933 17.1958ZM11.9993 14.9998C11.2037 14.9998 10.4406 14.6838 9.87801 14.1211C9.3154 13.5585 8.99933 12.7955 8.99933 11.9998C8.99933 11.2042 9.3154 10.4411 9.87801 9.8785C10.4406 9.31589 11.2037 8.99982 11.9993 8.99982C12.795 8.99982 13.558 9.31589 14.1206 9.8785C14.6833 10.4411 14.9993 11.2042 14.9993 11.9998C14.9993 12.7955 14.6833 13.5585 14.1206 14.1211C13.558 14.6838 12.795 14.9998 11.9993 14.9998ZM11.9993 12.9998C12.2645 12.9998 12.5189 12.8945 12.7064 12.7069C12.894 12.5194 12.9993 12.265 12.9993 11.9998C12.9993 11.7346 12.894 11.4803 12.7064 11.2927C12.5189 11.1052 12.2645 10.9998 11.9993 10.9998C11.7341 10.9998 11.4798 11.1052 11.2922 11.2927C11.1047 11.4803 10.9993 11.7346 10.9993 11.9998C10.9993 12.265 11.1047 12.5194 11.2922 12.7069C11.4798 12.8945 11.7341 12.9998 11.9993 12.9998V12.9998Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4100",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_SettingsSvg = (SettingsSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/WalletSvg.tsx

const WalletSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Wallet-Icon",
                clipPath: "url(#clip0_101_4122)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M18 7H21C21.2652 7 21.5196 7.10536 21.7071 7.29289C21.8946 7.48043 22 7.73478 22 8V20C22 20.2652 21.8946 20.5196 21.7071 20.7071C21.5196 20.8946 21.2652 21 21 21H3C2.73478 21 2.48043 20.8946 2.29289 20.7071C2.10536 20.5196 2 20.2652 2 20V4C2 3.73478 2.10536 3.48043 2.29289 3.29289C2.48043 3.10536 2.73478 3 3 3H18V7ZM4 9V19H20V9H4ZM4 5V7H16V5H4ZM15 13H18V15H15V13Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4122",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_WalletSvg = (WalletSvg);

;// CONCATENATED MODULE: ./components/Dashboard/Topbar/Topbar.tsx







const Topbar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full px-6 py-4 fixed right-0 left-0 top-0 z-10 flex justify-between items-center bg-secondary border-b border-tertiary text-white",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/apklogo-new.png",
                    width: 100,
                    height: 100,
                    alt: "apk logo"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-x-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(LanguageSelect, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Card_Iconcard, {
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_WalletSvg, {}),
                        animate: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Card_Iconcard, {
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_SettingsSvg, {}),
                        animate: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Card_Iconcard, {
                        icon: /*#__PURE__*/ jsx_runtime_.jsx(NotificationSvg/* default */.Z, {}),
                        badgeData: "8",
                        animate: true
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Topbar_Topbar = (Topbar);

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/DashboardSvg.tsx

const DashboardSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Dashboard-Icon",
                clipPath: "url(#clip0_101_4111)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M6.5 11.5C5.90905 11.5 5.32389 11.3836 4.77792 11.1575C4.23196 10.9313 3.73588 10.5998 3.31802 10.182C2.90016 9.76412 2.56869 9.26804 2.34254 8.72208C2.1164 8.17611 2 7.59095 2 7C2 6.40905 2.1164 5.82389 2.34254 5.27792C2.56869 4.73196 2.90016 4.23588 3.31802 3.81802C3.73588 3.40016 4.23196 3.06869 4.77792 2.84254C5.32389 2.6164 5.90905 2.5 6.5 2.5C7.69347 2.5 8.83807 2.97411 9.68198 3.81802C10.5259 4.66193 11 5.80653 11 7C11 8.19347 10.5259 9.33807 9.68198 10.182C8.83807 11.0259 7.69347 11.5 6.5 11.5V11.5ZM7 21.5C5.80653 21.5 4.66193 21.0259 3.81802 20.182C2.97411 19.3381 2.5 18.1935 2.5 17C2.5 15.8065 2.97411 14.6619 3.81802 13.818C4.66193 12.9741 5.80653 12.5 7 12.5C8.19347 12.5 9.33807 12.9741 10.182 13.818C11.0259 14.6619 11.5 15.8065 11.5 17C11.5 18.1935 11.0259 19.3381 10.182 20.182C9.33807 21.0259 8.19347 21.5 7 21.5V21.5ZM17 11.5C16.4091 11.5 15.8239 11.3836 15.2779 11.1575C14.732 10.9313 14.2359 10.5998 13.818 10.182C13.4002 9.76412 13.0687 9.26804 12.8425 8.72208C12.6164 8.17611 12.5 7.59095 12.5 7C12.5 6.40905 12.6164 5.82389 12.8425 5.27792C13.0687 4.73196 13.4002 4.23588 13.818 3.81802C14.2359 3.40016 14.732 3.06869 15.2779 2.84254C15.8239 2.6164 16.4091 2.5 17 2.5C18.1935 2.5 19.3381 2.97411 20.182 3.81802C21.0259 4.66193 21.5 5.80653 21.5 7C21.5 8.19347 21.0259 9.33807 20.182 10.182C19.3381 11.0259 18.1935 11.5 17 11.5V11.5ZM17 21.5C15.8065 21.5 14.6619 21.0259 13.818 20.182C12.9741 19.3381 12.5 18.1935 12.5 17C12.5 15.8065 12.9741 14.6619 13.818 13.818C14.6619 12.9741 15.8065 12.5 17 12.5C18.1935 12.5 19.3381 12.9741 20.182 13.818C21.0259 14.6619 21.5 15.8065 21.5 17C21.5 18.1935 21.0259 19.3381 20.182 20.182C19.3381 21.0259 18.1935 21.5 17 21.5ZM6.5 9.5C7.16304 9.5 7.79893 9.23661 8.26777 8.76777C8.73661 8.29893 9 7.66304 9 7C9 6.33696 8.73661 5.70107 8.26777 5.23223C7.79893 4.76339 7.16304 4.5 6.5 4.5C5.83696 4.5 5.20107 4.76339 4.73223 5.23223C4.26339 5.70107 4 6.33696 4 7C4 7.66304 4.26339 8.29893 4.73223 8.76777C5.20107 9.23661 5.83696 9.5 6.5 9.5V9.5ZM7 19.5C7.66304 19.5 8.29893 19.2366 8.76777 18.7678C9.23661 18.2989 9.5 17.663 9.5 17C9.5 16.337 9.23661 15.7011 8.76777 15.2322C8.29893 14.7634 7.66304 14.5 7 14.5C6.33696 14.5 5.70107 14.7634 5.23223 15.2322C4.76339 15.7011 4.5 16.337 4.5 17C4.5 17.663 4.76339 18.2989 5.23223 18.7678C5.70107 19.2366 6.33696 19.5 7 19.5ZM17 9.5C17.663 9.5 18.2989 9.23661 18.7678 8.76777C19.2366 8.29893 19.5 7.66304 19.5 7C19.5 6.33696 19.2366 5.70107 18.7678 5.23223C18.2989 4.76339 17.663 4.5 17 4.5C16.337 4.5 15.7011 4.76339 15.2322 5.23223C14.7634 5.70107 14.5 6.33696 14.5 7C14.5 7.66304 14.7634 8.29893 15.2322 8.76777C15.7011 9.23661 16.337 9.5 17 9.5ZM17 19.5C17.663 19.5 18.2989 19.2366 18.7678 18.7678C19.2366 18.2989 19.5 17.663 19.5 17C19.5 16.337 19.2366 15.7011 18.7678 15.2322C18.2989 14.7634 17.663 14.5 17 14.5C16.337 14.5 15.7011 14.7634 15.2322 15.2322C14.7634 15.7011 14.5 16.337 14.5 17C14.5 17.663 14.7634 18.2989 15.2322 18.7678C15.7011 19.2366 16.337 19.5 17 19.5Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4111",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_DashboardSvg = (DashboardSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/ExchangeSvg.tsx

const ExchangeSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Exchange-Icon",
                clipPath: "url(#clip0_101_4117)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22ZM12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20V20ZM7 13H16V15H12V18L7 13ZM12 9V6L17 11H8V9H12Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4117",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_ExchangeSvg = (ExchangeSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/TransactionSvg.tsx

const TransactionSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Transaction-Icon",
                clipPath: "url(#clip0_101_4153)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M19.3741 15.103C20.0229 13.5613 20.1723 11.855 19.8011 10.224C19.43 8.59303 18.557 7.11938 17.305 6.01024C16.0529 4.9011 14.4847 4.21225 12.8209 4.04055C11.1571 3.86884 9.48124 4.22292 8.02906 5.05299L7.03706 3.31599C8.5547 2.4486 10.2733 1.99435 12.0213 1.99856C13.7693 2.00278 15.4856 2.4653 16.9991 3.33999C21.4891 5.93199 23.2091 11.482 21.1161 16.11L22.4581 16.884L18.2931 19.098L18.1281 14.384L19.3741 15.103V15.103ZM4.62406 8.89699C3.97521 10.4387 3.82585 12.145 4.19698 13.776C4.56811 15.4069 5.44108 16.8806 6.69314 17.9897C7.9452 19.0989 9.51338 19.7877 11.1772 19.9594C12.8411 20.1311 14.5169 19.7771 15.9691 18.947L16.9611 20.684C15.4434 21.5514 13.7249 22.0056 11.9769 22.0014C10.2288 21.9972 8.5125 21.5347 6.99906 20.66C2.50906 18.068 0.789062 12.518 2.88206 7.88999L1.53906 7.11699L5.70406 4.90299L5.86906 9.61699L4.62306 8.89799L4.62406 8.89699ZM13.4141 14.828L10.5831 12L7.75506 14.828L6.34106 13.414L10.5841 9.17199L13.4131 12L16.2421 9.17199L17.6561 10.586L13.4131 14.828H13.4141Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4153",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_TransactionSvg = (TransactionSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/NewsSvg.tsx

const NewsSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "News-Icon",
                clipPath: "url(#clip0_101_4106)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M19 22H5C4.20435 22 3.44129 21.6839 2.87868 21.1213C2.31607 20.5587 2 19.7956 2 19V3C2 2.73478 2.10536 2.48043 2.29289 2.29289C2.48043 2.10536 2.73478 2 3 2H17C17.2652 2 17.5196 2.10536 17.7071 2.29289C17.8946 2.48043 18 2.73478 18 3V15H22V19C22 19.7956 21.6839 20.5587 21.1213 21.1213C20.5587 21.6839 19.7956 22 19 22ZM18 17V19C18 19.2652 18.1054 19.5196 18.2929 19.7071C18.4804 19.8946 18.7348 20 19 20C19.2652 20 19.5196 19.8946 19.7071 19.7071C19.8946 19.5196 20 19.2652 20 19V17H18ZM16 20V4H4V19C4 19.2652 4.10536 19.5196 4.29289 19.7071C4.48043 19.8946 4.73478 20 5 20H16ZM6 7H14V9H6V7ZM6 11H14V13H6V11ZM6 15H11V17H6V15Z",
                    fill: "#F0F4F7"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4106",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_NewsSvg = (NewsSvg);

;// CONCATENATED MODULE: ./components/Bottombar/MobileNav.tsx








const MobileNav = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full flex justify-center text-white fixed bottom-5 lg:hidden",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-[80%] flex justify-around bg-[#587BF2] px-4 py-3 rounded-xl z-100",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_DashboardSvg, {
                        size: "medium"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_ExchangeSvg, {
                        size: "medium"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_WalletSvg, {
                        size: "medium"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_TransactionSvg, {
                        size: "medium"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(ScaleAnimate, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_NewsSvg, {
                        size: "medium"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const Bottombar_MobileNav = (MobileNav);

;// CONCATENATED MODULE: ./redux/provider.tsx

const provider_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\redux\provider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: provider_esModule, $$typeof: provider_$$typeof } = provider_proxy;
const provider_default_ = provider_proxy.default;

const e0 = provider_proxy["Providers"];


/* harmony default export */ const provider = (provider_default_);
// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(63919);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(78875);
;// CONCATENATED MODULE: ./app/(dashboard)/layout.tsx









const metadata = {
    title: "APK Exchange",
    description: "Site to trade giftcards"
};
function RootLayout({ children }) {
    const cookieStore = (0,headers.cookies)();
    const accessToken = cookieStore.get("access");
    if (accessToken === undefined) {
        return (0,navigation.redirect)("/login");
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
            className: `${(target_path_app_dashboard_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter_default()).className} w-screen bg-tertiary flex h-screen  overflow-hidden`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full flex flex-col ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Topbar_Topbar, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full flex flex-col pt-20  py-2 overflow-y-auto  ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(provider, {
                                children: children
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Bottombar_MobileNav, {})
            ]
        })
    });
}


/***/ }),

/***/ 7327:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35465);


const Card = ({ children, className })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: ` ${className} text-white  relative  rounded-lg text-sm px-5 py-2.5 `,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);


/***/ }),

/***/ 20350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const NotificationSvg = ({ size })=>{
    let iconSize;
    switch(size){
        case "small":
            iconSize = "w-5 h-5";
            break;
        case "medium":
            iconSize = "w-8 h-8";
            break;
        case "large":
            iconSize = "w-12 h-12";
            break;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        className: `${size ? iconSize : "w-5 h-5"}`,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "Notification-Icon",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                id: "Vector",
                d: "M5 18H19V11.031C19 7.148 15.866 4 12 4C8.134 4 5 7.148 5 11.031V18ZM12 2C16.97 2 21 6.043 21 11.031V20H3V11.031C3 6.043 7.03 2 12 2ZM9.5 21H14.5C14.5 21.663 14.2366 22.2989 13.7678 22.7678C13.2989 23.2366 12.663 23.5 12 23.5C11.337 23.5 10.7011 23.2366 10.2322 22.7678C9.76339 22.2989 9.5 21.663 9.5 21V21Z",
                fill: "white"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotificationSvg);


/***/ })

};
;