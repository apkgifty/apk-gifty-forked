"use strict";
exports.id = 5516;
exports.ids = [5516];
exports.modules = {

/***/ 43429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Nav_Navigation)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./components/UI/LanguageSelect.tsx
var LanguageSelect = __webpack_require__(74816);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(64085);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/Menu.js
var Menu = __webpack_require__(43900);
;// CONCATENATED MODULE: ./components/UI/MenuButton.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const MenuButton = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(node.IconButton, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Menu/* default */.Z, {
            className: "text-white"
        })
    });
};
/* harmony default export */ const UI_MenuButton = (MenuButton);

// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./components/Nav/NavigationItem.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const NavigationItem = ({ title, link })=>{
    const pathName = (0,navigation.usePathname)();
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: link,
        className: `${pathName.includes(link) ? "text-violet-500" : "text-white"} hover:underline`,
        children: title
    });
};
/* harmony default export */ const Nav_NavigationItem = (NavigationItem);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 192 modules
var motion = __webpack_require__(82314);
;// CONCATENATED MODULE: ./components/Nav/Navigation.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const mainNavigationLinks = [
    {
        title: "Home",
        link: "/"
    },
    {
        title: "About",
        link: "/about"
    },
    {
        title: "Buy GiftCards",
        link: "/dashboard/exchange/buy"
    },
    {
        title: "Contact",
        link: "#"
    },
    {
        title: "Promotion",
        link: "#"
    },
    {
        title: "Blog",
        link: "#"
    }
];
const Navigation = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full flex justify-between items-center ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-12",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        transition: {
                            duration: 1
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/images/apklogo-new.png",
                                width: 100,
                                height: 100,
                                alt: "apk logo",
                                priority: true,
                                className: "-mt-2"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "hidden lg:flex space-x-6",
                        children: mainNavigationLinks.map((navItem)=>/*#__PURE__*/ jsx_runtime_.jsx(Nav_NavigationItem, {
                                title: navItem.title,
                                link: navItem.link
                            }, navItem.title))
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden lg:flex lg:gap-x-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "space-x-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/login",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "bg-tertiary px-3 py-2 text-sm font-medium rounded-lg",
                                    children: "Login"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/signup",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "bg-appviolet px-3 py-2 text-sm font-medium rounded-lg",
                                    children: "Signup"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(LanguageSelect["default"], {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "lg:hidden",
                children: /*#__PURE__*/ jsx_runtime_.jsx(UI_MenuButton, {})
            })
        ]
    });
};
/* harmony default export */ const Nav_Navigation = (Navigation);


/***/ }),

/***/ 35311:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const AppLayout = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full md:max-w-6xl mx-auto",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppLayout);


/***/ }),

/***/ 84094:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Nav_Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./components/Layout/AppLayout.tsx
var AppLayout = __webpack_require__(35311);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Nav/Navigation.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Nav\Navigation.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const Navigation = (__default__);
;// CONCATENATED MODULE: ./components/Nav/Navbar.tsx



const Navbar = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full px-5 py-4 bg-secondary text-white",
        children: /*#__PURE__*/ jsx_runtime_.jsx(AppLayout/* default */.Z, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Navigation, {})
        })
    });
};
/* harmony default export */ const Nav_Navbar = (Navbar);


/***/ })

};
;