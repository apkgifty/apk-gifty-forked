"use strict";
exports.id = 755;
exports.ids = [755];
exports.modules = {

/***/ 50755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FormComponents_Switch)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Form/FormComponents/ToggleButton.tsx


const ToggleButton = ({ color, title, handleSwitch, url })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: url,
        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            className: `px-4 py-2 text-xs rounded-xl transition-colors duration-300 ${color} lg:text-sm`,
            onClick: ()=>handleSwitch(url),
            children: title
        })
    });
};
/* harmony default export */ const FormComponents_ToggleButton = (ToggleButton);

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 192 modules
var motion = __webpack_require__(82314);
;// CONCATENATED MODULE: ./components/Form/FormComponents/Switch.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Switch = ({ items, backgroundColor })=>{
    const [activeOption, setActiveOption] = (0,react_experimental_.useState)("");
    (0,react_experimental_.useEffect)(()=>{
        const pathArray = window.location.href.split("/");
        const path = pathArray[pathArray.length - 1];
        setActiveOption(path);
    }, []);
    const handleSwitch = (option)=>{
        setActiveOption(option);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion */.E.div, {
        className: "flex ",
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            duration: 1,
            ease: "easeOut"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `max-w-md p-1   rounded-xl ${backgroundColor}`,
            children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(FormComponents_ToggleButton, {
                    title: item.label,
                    color: activeOption === item.url ? "bg-[#587BF2]" : "bg-transparent",
                    handleSwitch: handleSwitch,
                    url: item.url
                }, item.label))
        })
    });
};
/* harmony default export */ const FormComponents_Switch = (Switch);


/***/ })

};
;