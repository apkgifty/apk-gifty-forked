"use strict";
exports.id = 3874;
exports.ids = [3874];
exports.modules = {

/***/ 73874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(82314);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const FormInput = ({ icon, type, placeholder, name, config, register, errors, className, defaultValue, readOnly })=>{
    const j = register ? {
        ...register(name, config)
    } : {
        ...{}
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion */ .E.div, {
        className: `w-full px-2 py-2  rounded-xl flex gap-2 lg:py-3 ${className} `,
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            duration: 1
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `px-2 border-r border-gray-400 ${errors && errors[name] && "text-red-600"}`,
                children: icon
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: type,
                className: "bg-transparent outline-none text-xs lg:text-sm w-full",
                placeholder: placeholder,
                // name={name}
                autoComplete: "off",
                defaultValue: defaultValue,
                readOnly: readOnly,
                ...j
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormInput);


/***/ })

};
;