(() => {
var exports = {};
exports.id = 6691;
exports.ids = [6691];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 93704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'refund-policy',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51763)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\refund-policy\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31713)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\refund-policy\\page.tsx"];
    
    const originalPathname = "/(main)/refund-policy/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 34914:
/***/ (() => {



/***/ }),

/***/ 51763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./components/Layout/AppLayout.tsx
var AppLayout = __webpack_require__(35311);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./app/refund-policy.mdx
/*@jsxRuntime automatic @jsxImportSource react*/ 
function _createMdxContent(props) {
    const _components = Object.assign({
        p: "p",
        strong: "strong",
        ul: "ul",
        li: "li"
    }, props.components);
    return (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Return and Refund Policy"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Thank you for shopping at Apkxchange."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "If, for any reason, You are not completely satisfied with a purchase We invite You to review our policy on refunds."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "The following terms are applicable for any products that You purchased with Us."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Interpretation and Definitions"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Interpretation"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "The words of which the initial letter is capitalized have meanings defined under the following conditions. The following definitions shall have the same meaning regardless of whether they appear in singular or in plural."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Definitions"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "For the purposes of this Return and Refund Policy:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Company"
                            }),
                            ' (referred to as either "the Company", "We", "Us" or "Our" in this Agreement) refers to Apkxchange.'
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Goods"
                            }),
                            " refer to the items (Payment methods) offered for sale on the Service."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Orders"
                            }),
                            " mean a request by You to purchase Goods from Us."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Service"
                            }),
                            " refers to the Website."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Website"
                            }),
                            " refers to Apkxchange, accessible from (www.apkxchange.com)"
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "You"
                            }),
                            " means the individual accessing or using the Service, or the company, or other legal entity on behalf of which such individual is accessing or using the Service, as applicable."
                        ]
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Your Order Cancellation Rights"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You are entitled to cancel Your Order within [2] days without giving any reason for doing so."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "The deadline for cancelling an Order is [2] days from the date on which You received the Goods or on which a third party you have appointed, who is not the carrier, takes possession of the product delivered. For Gift Cards services on the website Refunds can be issued by ",
                    jsx_runtime_.jsx(_components.strong, {
                        children: "User"
                    }),
                    " when the payment has been made and the ",
                    jsx_runtime_.jsx(_components.strong, {
                        children: "Goods"
                    }),
                    " hasn't been delivered yet."
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "In order to exercise Your right of cancellation, You must inform Us of your decision by means of a clear statement. You can inform us of your decision by:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "By email: [apkxchange@aol.com]"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "By Telegram: [@apkxchange]"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We will reimburse You no later than [5] days from the day on which We receive the returned Goods. We will use the same means of payment as You used for the Order, and You will not incur any fees for such reimbursement."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Provided that the goods/products shall only be returned or the same shall be considered if the products/goods are faulty or damaged."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Conditions for Returns"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "In order for the Goods to be eligible for a return, please make sure that:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "if you make payment to our system and we suddenly became out of stock for said gift card refund will be made to the user account."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "The following Goods cannot be returned:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "The supply of Goods made to Your specifications or clearly personalized."
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "The supply of Goods which according to their nature are not suitable to be returned, or shall have near expiry."
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "The supply of Goods which are, after delivery, according to their nature, inseparably mixed with other items"
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            "Once a gift card has been issued a ",
                            jsx_runtime_.jsx(_components.strong, {
                                children: "User"
                            }),
                            " has a 30mins time frame to use the gift card provided. Before a gift card will be issued to a buyer the balance and everything would have been confirmed already. Hence it is more important to make sure you're ready to use a gift card once you make payment for an order. Failure to use the card within the timeframe and extending that timeframes comes at a risk where refund may not be possible once card has been provided with balance intact."
                        ]
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Make sure the gift card you're purchasing matches your account region. Most gift cards we will provide region are mostly USA."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We reserve the right to refuse returns of any goods/services that does not meet the above return conditions in our sole discretion."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Only regular priced Goods may be refunded. Unfortunately, Goods on sale/promotion cannot be refunded/exchanged. This exclusion may not apply to You if it is not permitted by applicable law."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Contact Us"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "If you have any questions about our Returns and Refunds Policy, please contact us:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "By email: [apkxchange@aol.com]"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "By Telegram: [@apkxchange]"
                    }),
                    "\n"
                ]
            })
        ]
    });
}
function MDXContent(props = {}) {
    const { wrapper: MDXLayout } = props.components || {};
    return MDXLayout ? jsx_runtime_.jsx(MDXLayout, Object.assign({}, props, {
        children: jsx_runtime_.jsx(_createMdxContent, props)
    })) : _createMdxContent(props);
}
/* harmony default export */ const refund_policy = (MDXContent);

;// CONCATENATED MODULE: ./app/(main)/refund-policy/page.tsx




const RefundPolicy = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full text-white py-8",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AppLayout/* default */.Z, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-center text-xl lg:text-3xl font-bold lg:pb-10",
                    children: "Refund Policy"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "space-y-4 px-3 lg:px-0 text-sm",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(refund_policy, {})
                })
            ]
        })
    });
};
/* harmony default export */ const page = (RefundPolicy);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,8421,9103,3592,993,8245,1635,5516,4579], () => (__webpack_exec__(93704)));
module.exports = __webpack_exports__;

})();