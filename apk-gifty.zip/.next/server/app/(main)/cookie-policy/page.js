(() => {
var exports = {};
exports.id = 7182;
exports.ids = [7182];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 64313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'cookie-policy',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 93268)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\cookie-policy\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31713)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\cookie-policy\\page.tsx"];
    
    const originalPathname = "/(main)/cookie-policy/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 34914:
/***/ (() => {



/***/ }),

/***/ 93268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./components/Layout/AppLayout.tsx
var AppLayout = __webpack_require__(35311);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./app/cookie-policy.mdx
/*@jsxRuntime automatic @jsxImportSource react*/ 
function _createMdxContent(props) {
    const _components = Object.assign({
        p: "p",
        strong: "strong",
        a: "a",
        ul: "ul",
        li: "li"
    }, props.components);
    return (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Cookie Policy"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "This is the Cookie Policy for Apkxchange, accessible at ",
                    jsx_runtime_.jsx(_components.a, {
                        href: "the",
                        title: " **Website**",
                        children: "www.apkxchange.com"
                    }),
                    '. These terms and conditions of the Cookies Policy (the " ',
                    jsx_runtime_.jsx(_components.strong, {
                        children: "Policy"
                    }),
                    '"), expressly declare and outline the rules and regulations upon which the Website handles cookies. The Policy is a conditions precedent for the use of the Website.'
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "What Are Cookies"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "It is a most common and appropriate practice, with almost all professional websites this Website use cookies, which are tiny files that are downloaded to your computer, to improve your experience. This page describes what information is gathered through the use of the cookies, how it is operated and used and when it is stored. This page also describes how one can prevent the Website from the use of the cookies. If you do not allow the cookies at your site this may halt certain features of the Website."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Disable Cookies"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You do have the right to disable cookies all the time, furthermore, the Website do also ask you if you want to allow the cookies or not. You can permanently block the cookies from the help option on your browser. This is a total discretion of the user, but a recommendation is always forwarded to allow the cookies to have a better experience of the Website."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "The Cookies We Set"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Cookies related to account signup"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "If you sign up with us on the Website, we will use cookies for the management of the signup process and general management. These cookies are generally left out of the scene when you log out from your account, in certain cases these cookies are not deleted in order to keep you updated on the website to assist you further in again signing up."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Cookies related to Login"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We use cookies when you are logged in so that we can remember this fact. This prevents you from having to log in every single time you visit a new page. These cookies are typically removed or cleared when you log out to ensure that you can only access restricted features and areas when logged in."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Forms related cookies"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "When you submit data to through a form such as those found on contact pages or comment forms cookies may be set to remember your user details for future correspondence."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Third Party Cookies"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "In some special cases we also use cookies provided by trusted third parties. The following section details which third party cookies you might encounter through this site."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "This site uses Google Analytics which is one of the most widespread and trusted analytics solution on the web for helping us to understand how you use the site and ways that we can improve your experience. These cookies may track things such as how long you spend on the site and the pages that you visit so we can continue to produce engaging content."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "For more information on Google Analytics cookies, see the official Google Analytics page."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Third party analytics are used to track and measure usage of this site so that we can continue to produce engaging content. These cookies may track things such as how long you spend on the site or pages you visit which helps us to understand how we can improve the site for you."
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "From time to time we test new features and make subtle changes to the way that the site is delivered. When we are still testing new features these cookies may be used to ensure that you receive a consistent experience whilst on the site whilst ensuring we understand which optimizations our users appreciate the most."
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "As we sell products it's important for us to understand statistics about how many of the visitors to our site actually make a purchase and as such this is the kind of data that these cookies will track. This is important to you as it means that we can accurately make business predictions that allow us to monitor our advertising and product costs to ensure the best possible price."
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "The Google AdSense service we use to serve advertising uses a DoubleClick cookie to serve more relevant ads across the web and limit the number of times that a given ad is shown to you."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "For more information on Google AdSense see the official Google AdSense privacy FAQ."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ul, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "We also use social media buttons and/or plugins on this site that allow you to connect with your social network in various ways. For these to work the following social media sites including; will set cookies through our site which may be used to enhance your profile on their site or contribute to the data they hold for various purposes outlined in their respective privacy policies."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "More Information"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Hopefully that has clarified things for you and as was previously mentioned if there is something that you aren't sure whether you need or not it's usually safer to leave cookies enabled in case it does interact with one of the features you use on our site."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "However if you are still looking for more information than you can contact us through one of our preferred contact methods:"
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "(apkxchange@aol.com)"
            })
        ]
    });
}
function MDXContent(props = {}) {
    const { wrapper: MDXLayout } = props.components || {};
    return MDXLayout ? jsx_runtime_.jsx(MDXLayout, Object.assign({}, props, {
        children: jsx_runtime_.jsx(_createMdxContent, props)
    })) : _createMdxContent(props);
}
/* harmony default export */ const cookie_policy = (MDXContent);

;// CONCATENATED MODULE: ./app/(main)/cookie-policy/page.tsx




const CookiePolicy = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full text-white py-8",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AppLayout/* default */.Z, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-center text-xl lg:text-3xl font-bold lg:pb-10",
                    children: "Cookie Policy"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "space-y-4 px-3 lg:px-0 text-sm ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(cookie_policy, {})
                })
            ]
        })
    });
};
/* harmony default export */ const page = (CookiePolicy);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,8421,9103,3592,993,8245,1635,5516,4579], () => (__webpack_exec__(64313)));
module.exports = __webpack_exports__;

})();