(() => {
var exports = {};
exports.id = 464;
exports.ids = [464];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 41519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'privacy-policy',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42830)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\privacy-policy\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31713)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\privacy-policy\\page.tsx"];
    
    const originalPathname = "/(main)/privacy-policy/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 34914:
/***/ (() => {



/***/ }),

/***/ 42830:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
// EXTERNAL MODULE: ./components/Layout/AppLayout.tsx
var AppLayout = __webpack_require__(35311);
;// CONCATENATED MODULE: ./app/privacy-policy.mdx
/*@jsxRuntime automatic @jsxImportSource react*/ 
function _createMdxContent(props) {
    const _components = Object.assign({
        h1: "h1",
        p: "p",
        strong: "strong",
        ol: "ol",
        li: "li",
        em: "em",
        h2: "h2",
        img: "img"
    }, props.components);
    return (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx(_components.h1, {
                children: "PRIVACY POLICY"
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Introduction"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    'These terms and conditions of the Privacy Policy (the " ',
                    jsx_runtime_.jsx(_components.strong, {
                        children: "Policy"
                    }),
                    '") of Apkxchange, expressly declare and outline the rules and regulations for the use of, located at www.apkxchange.com (the " ',
                    jsx_runtime_.jsx(_components.strong, {
                        children: "Website"
                    }),
                    '"). The Terms and Conditions are conditions precedent for the use of the Website. By accessing/using/recommending/signing up/referring to someone/opening a link to the Website, we assume you accept these terms and conditions, and you declare that you expressly accept the Terms and Conditions of the Website without any force and coercion. You are hereby warned and made clear without any kind of ambiguity that if you do not accept these Terms and Conditions you may not proceed further. You are also being made aware that if you sign up/move forward/access/recommend to someone without accepting the Terms and Conditions, you would keep, Website, its owners/affiliates/employees and all person affiliated with Website, harmless and you waive off all your rights to sue the Website its owners and all affiliates. Do not continue to use Website if you do not agree to take all of the terms and conditions stated on this page. You accept the Terms by remaining on the Website.'
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Definitions"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Services/Products"
                            }),
                            " means the gift cards/provisioning of gift cards and other payment methods."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Personal Data"
                            }),
                            " means data about a living individual who can be identified from those data (or from those and other information either in our possession or likely to come into our possession)."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Usage**"
                            }),
                            " Data** is data collected automatically either generated by the use of Service or from Service infrastructure itself (for example, the duration of a page visit)."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Cookies"
                            }),
                            " are small files stored on your device (computer or mobile device)."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Data**"
                            }),
                            " Controller** means a natural or legal person who (either alone or jointly or in common with other persons) determines the purposes for which and the manner in which any personal data are, or are to be, processed. For the purpose of this Privacy Policy, we are a Data Controller of your data."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Service Provider"
                            }),
                            " means any natural or legal person who processes the data on behalf of the Data Controller. We may use the services of various Service Providers in order to process your data more effectively."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "Data**"
                            }),
                            " Subject** is any living individual who is the subject of Personal Data."
                        ]
                    }),
                    "\n",
                    (0,jsx_runtime_.jsxs)(_components.li, {
                        children: [
                            jsx_runtime_.jsx(_components.strong, {
                                children: "The**"
                            }),
                            " User** is the individual using our Service. The User corresponds to the Data Subject, who is the subject of Personal Data."
                        ]
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "We respect your privacy"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "We adhere to the National Privacy Principles established by the ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "Privacy Act"
                    }),
                    " 1988 (Cth), GDPR, CCPA and all other privacy laws and laws that protects privacy of people of all over the world. This Policy sets out how we collect and treat your personal information."
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Personal Data"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "While using our Website, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you. Personally identifiable information may include, but is not limited to:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Email address"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "First name and last name"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Phone number"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Address, State, Province, ZIP/Postal code, City"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Cookies and Usage Data"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Bank details,"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "Credit/debit card details that may include billing address, identity details, and professional profile"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Usage Data"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We may collect information that your browser sends whenever you use the Website or when you access Website by or through any device."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "This Data may include information such as your computer's Internet Protocol address (e.g. IP address). When you access Website with a device, this Usage Data may include information such as the type of device you use, your device unique ID, the IP address of your device, your device operating system, unique device identifiers and other diagnostic data."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Tracking Cookies Data"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We use cookies and similar tracking technologies to track the activity on our Website and we hold certain information."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Cookies are files with a small amount of data which may include an anonymous unique identifier. Cookies are sent and stored on your device. Other tracking technologies are also used such as beacons, tags and scripts to collect and track information and to improve and analyze our Service."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You can instruct your device to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Website."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Other Data"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "While using our Website, we may also collect the following information: sex, age, date of birth, place of birth, passport details, citizenship, registration at place of residence and actual address, telephone number (work, mobile), details of documents on education, qualification, professional training, employment agreements, information on bonuses and compensation, information on marital status, family members, office location and other data."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You may provide basic information such as your name, phone number, and address, likes dislikes, profile pictures and videos and email address to enable us to send information, provide updates. We may collect additional information at other times, including but not limited to, when you provide feedback, when you provide information about your personal or business affairs, change your content or email preference, respond to surveys and/or promotions, provide financial or credit card information, or communicate with our customer support."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Additionally, we may also collect any other information you provide while interacting with us, such as commerce products, may require you to provide us with a debit or credit card number and its associated account information."
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "How we collect your personal information"
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Website collects personal information from you in a variety of ways, including when you interact with us electronically or in person, when you access our Website and when we provide our services to you. We may receive personal information from third parties. If we do, we will protect it as set out in this Policy."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Use of Data"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Website uses the collected data for various purposes:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to provide and maintain our Website/services;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to notify you about changes to our Website/service;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to allow you to participate in interactive features of our Website when you choose to do so;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to provide customer support;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to gather analysis or valuable information so that we can improve our Website/Service;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to monitor the usage of our Website/Service;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to detect, prevent and address technical issues;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to fulfil any other purpose for which you provide it;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to carry out our obligations and enforce our rights arising from any contracts entered into between you and us, including for billing and collection;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to provide you with notices about your account and/or subscription, including expiration and renewal notices, email-instructions, etc.;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "to provide you with news, special offers and general information about other goods, services and events which we offer that are similar to those that you have already purchased or enquired about unless you have opted not to receive such information;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "in any other way we may describe when you provide the information;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "for any other purpose with your consent."
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "Security of your personal information"
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We are committed to ensuring that the information you provide to us is secure. In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure information and protect it from misuse, interference, loss and unauthorised access, modification and disclosure."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "The transmission and exchange of information is carried out at your own risk. We cannot guarantee the security of any information that you transmit to us, or receive from us. Although we take measures to safeguard against unauthorised disclosures of information, we cannot assure you that personal information that we collect will not be disclosed in a manner that is inconsistent with this Policy."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Data Protection Act 2012 (Ghana)"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "If you are resident of Ghana, you have certain rights as prescribe by the Data Protection Act, 2012 (Act 843) which sets out the rules and principles governing the collection, use, disclosure and care for your personal data or information by a data controller or processor. We recognises your right (data subject rights) to protect your personal data or information by mandating a data controller or processor to process (collect, use, disclose, erase, etc) such personal data or information in accordance with your rights. This Act also established the Data Protection Commission as an independent statutory body to whom you can consult to ensure and enforce compliance."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Your Data Protection Rights Under General Data Protection Regulation (GDPR)"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "If you are a resident of the European Union (EU) and European Economic Area (EEA), you have certain data protection rights, covered by GDPR."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We aim to take reasonable steps to allow you to correct, amend, delete, or limit the use of your Personal Data."
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "If you wish to be informed what Personal Data we hold about you and if you want it to be removed from our systems, please email us at ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    })
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "In certain circumstances, you have the following data protection rights:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to access, update or to delete the information we have on you;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right of rectification. You have the right to have your information rectified if that information is inaccurate or incomplete;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to object. You have the right to object to our processing of your Personal Data;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right of restriction. You have the right to request that we restrict the processing of your personal information;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to data portability. You have the right to be provided with a copy of your Personal Data in a structured, machine-readable and commonly used format;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to withdraw consent. You also have the right to withdraw your consent at any time where we rely on your consent to process your personal information;"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Please note that we may ask you to verify your identity before responding to such requests. Please note, we may not able to provide Service without some necessary data."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You have the right to complain to a Data Protection Authority about our collection and use of your Personal Data. For more information, please contact your local data protection authority in the European Economic Area (EEA)."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Your Data Protection Rights under the California Privacy Protection Act (CalOPPA)"
                })
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "CalOPPA is the first state law in the nation to require commercial websites and online services to post a privacy policy. The law's reach stretches well beyond California to require a person or company in the United States (and conceivable the world) that operates websites collecting personally identifiable information from California consumers to post a conspicuous privacy policy on its website stating exactly the information being collected and those individuals with whom it is being shared, and to comply with this policy."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "According to CalOPPA we agree to the following:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "users can visit our site anonymously;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: 'our Privacy Policy link includes the word "Privacy", and can easily be found on the home page of our website;'
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "users will be notified of any privacy policy changes on our Privacy Policy Page;"
                    }),
                    "\n"
                ]
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "users are able to change their personal information by emailing us at ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    })
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Privacy Act and Privacy Principles Australia"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "This is to make it clear that you always have the right and you are hereby being consented by the us and the Website that you can always change the choose to opt that your information may not be acquired, if acquired may kindly be deleted, may not be shared. You can do the same by contacting us at our email ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    })
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "In express terms and in certain circumstances, you always have the following data protection rights:"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.ol, {
                children: [
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to access, update or to delete the information we have on you;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right of rectification. You have the right to have your information rectified if that information is inaccurate or incomplete;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to object. You have the right to object to our processing of your Personal Data;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right of restriction. You have the right to request that we restrict the processing of your personal information;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to data portability. You have the right to be provided with a copy of your Personal Data in a structured, machine-readable and commonly used format;"
                    }),
                    "\n",
                    jsx_runtime_.jsx(_components.li, {
                        children: "the right to withdraw consent. You also have the right to withdraw your consent at any time where we rely on your consent to process your personal information;"
                    }),
                    "\n"
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Please note that we may ask you to verify your identity before responding to such requests. Please note, we may not able to provide Service without some necessary data."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "You have the right to complain to a Data Protection Authority about our collection and use of your Personal Data."
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {}),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "Complaints about privacy"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "If you have any complaints about our privacy practices, please feel free to send in details of your complaints to ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    })
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We take complaints very seriously and will respond shortly after receiving written notice of your complaint. We shall do our best to solve any issue with due care and diligence."
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "Op out right"
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "You can stop all collection of information by the Website easily by uninstalling the Website. You may use the standard uninstall processes as may be available as part of your mobile device or via the mobile application marketplace or network. You can also request to opt-out via email, ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    })
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.h1, {
                children: "Changes to Policy"
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "Please be aware that we may change this Policy in the future. We may modify this Policy at any time, in our sole discretion and all modifications will be effective immediately upon our posting of the modifications on our website or notice board. Please check back from time to time to review our Policy."
            }),
            "\n",
            jsx_runtime_.jsx(_components.h2, {}),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Children's Privacy"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "Our Services are not intended for use by children under the age of 13 ( ",
                    jsx_runtime_.jsx(_components.strong, {
                        children: '"Child"'
                    }),
                    " or ",
                    jsx_runtime_.jsx(_components.strong, {
                        children: '"Children"'
                    }),
                    " )."
                ]
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: "We do not knowingly collect personally identifiable information from Children under 13. If you become aware that a Child has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from Children without verification of parental consent, we take steps to remove that information from our servers."
            }),
            "\n",
            jsx_runtime_.jsx(_components.p, {
                children: jsx_runtime_.jsx(_components.strong, {
                    children: "Contact us"
                })
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    "If you have any questions, complaints, concerns or comments on our Privacy Policy, we welcome you to contact us by sending an email to ",
                    jsx_runtime_.jsx(_components.em, {
                        children: "privacy.apkxchange@aol.com"
                    }),
                    '. Your indication at the subject header would assist us in attending to your email speedily by passing it on to the relevant staff in our organisation. For example, you could insert the subject header as "Accessing Personal Data".'
                ]
            }),
            "\n",
            (0,jsx_runtime_.jsxs)(_components.p, {
                children: [
                    jsx_runtime_.jsx(_components.img, {
                        src: "RackMultipart20230808-1-n68ld_html_543b9649299b328c.gif",
                        alt: "Shape2"
                    }),
                    " ",
                    jsx_runtime_.jsx(_components.img, {
                        src: "RackMultipart20230808-1-n68ld_html_8492d464b91f651c.gif",
                        alt: "Shape1"
                    })
                ]
            })
        ]
    });
}
function MDXContent(props = {}) {
    const { wrapper: MDXLayout } = props.components || {};
    return MDXLayout ? jsx_runtime_.jsx(MDXLayout, Object.assign({}, props, {
        children: jsx_runtime_.jsx(_createMdxContent, props)
    })) : _createMdxContent(props);
}
/* harmony default export */ const privacy_policy = (MDXContent);

;// CONCATENATED MODULE: ./app/(main)/privacy-policy/page.tsx




const PrivacyPolicy = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full text-white py-8",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AppLayout/* default */.Z, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "text-center text-xl lg:text-3xl font-bold lg:pb-10",
                    children: "PRIVACY POLICIES"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "space-y-4 px-3 lg:px-0 text-sm",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(privacy_policy, {})
                })
            ]
        })
    });
};
/* harmony default export */ const page = (PrivacyPolicy);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,8421,9103,3592,993,8245,1635,5516,4579], () => (__webpack_exec__(41519)));
module.exports = __webpack_exports__;

})();