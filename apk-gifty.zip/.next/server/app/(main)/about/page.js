(() => {
var exports = {};
exports.id = 2214;
exports.ids = [2214];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 75670:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'about',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 36438)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\about\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 31713)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(main)\\about\\page.tsx"];
    
    const originalPathname = "/(main)/about/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 59981:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63912, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23))

/***/ }),

/***/ 36438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./components/Main/MainButton.tsx
var MainButton = __webpack_require__(2138);
;// CONCATENATED MODULE: ./components/Main/AboutBlock.tsx


const AboutBlock = ({ children, title, buttonText, link, icon })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "text-white w-full flex-1",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-4 items-center mb-3",
                children: [
                    icon && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: icon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "text-base lg:text-xl font-bold",
                        children: title
                    })
                ]
            }),
            children,
            buttonText && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "py-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx(MainButton/* default */.Z, {
                    buttonText: buttonText,
                    link: link,
                    className: "text-sm lg:text-base"
                })
            })
        ]
    });
};
/* harmony default export */ const Main_AboutBlock = (AboutBlock);

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./components/Main/Banner.tsx


const Banner = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full py-[75px] flex justify-center items-center text-white bg-cover bg-no-repeat bg-center",
        style: {
            backgroundImage: "url(https://s3-alpha-sig.figma.com/img/b253/27be/0b16afa14396c2834f6b3caf50da18a5?Expires=1691971200&Signature=QOyS6pyyAnBmu8KeQONH5XyHhWsBZIRpLVsAbfPuPWM-u4HNdJkfw73o~k2PQqaB367RF3Ww4GhCIBroDKGcxE5JwPvC~Zp5ID~XXM-uz5bosLP12VMZ3QaKbAzN4~f6f6VdEyttOu48G~LBU-1SqsiqRWTIbq~DjLOgON0tqRD134X9pKKJQw7kvZQXDHBFydIbdI6C7VhGPA-OIaLeUm7KgCJUEMNKxTc7PzjIIkNVgwBbpFczCvlih2d8tcKrpP9F52MLVjOhWwP8hg~OlcyH3B0kjebGFKVPEwUjRMG1ZXlNlFf8nq8pXGtC4Vlf6Eq0O1-fSqkbk1f5D9UbcA__&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4)"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
            className: "text-3xl max-w-[250px]  lg:text-6xl font-bold lg:max-w-md text-center",
            children: "Crypto Trading Made Easy"
        })
    });
};
/* harmony default export */ const Main_Banner = (Banner);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/AboutDiscountSvg.tsx


const AboutDiscountSvg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "bxs:discount",
            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                id: "Vector",
                d: "M21 5H3C2.73478 5 2.48043 5.10536 2.29289 5.29289C2.10536 5.48043 2 5.73478 2 6V10H2.893C3.889 10 4.813 10.681 4.973 11.664C5.02174 11.951 5.00726 12.2453 4.93056 12.5261C4.85387 12.807 4.71681 13.0677 4.52894 13.2902C4.34108 13.5126 4.10694 13.6913 3.84287 13.8139C3.57879 13.9365 3.29115 14 3 14H2V18C2 18.2652 2.10536 18.5196 2.29289 18.7071C2.48043 18.8946 2.73478 19 3 19H21C21.2652 19 21.5196 18.8946 21.7071 18.7071C21.8946 18.5196 22 18.2652 22 18V14H21C20.7089 14 20.4212 13.9365 20.1571 13.8139C19.8931 13.6913 19.6589 13.5126 19.4711 13.2902C19.2832 13.0677 19.1461 12.807 19.0694 12.5261C18.9927 12.2453 18.9783 11.951 19.027 11.664C19.187 10.681 20.111 10 21.107 10H22V6C22 5.73478 21.8946 5.48043 21.7071 5.29289C21.5196 5.10536 21.2652 5 21 5ZM9 9C9.26522 9 9.51957 9.10536 9.70711 9.29289C9.89464 9.48043 10 9.73478 10 10C10 10.2652 9.89464 10.5196 9.70711 10.7071C9.51957 10.8946 9.26522 11 9 11C8.73478 11 8.48043 10.8946 8.29289 10.7071C8.10536 10.5196 8 10.2652 8 10C8 9.73478 8.10536 9.48043 8.29289 9.29289C8.48043 9.10536 8.73478 9 9 9ZM8.2 15.4L14.2 7.4L15.8 8.6L9.8 16.6L8.2 15.4ZM15 15C14.7348 15 14.4804 14.8946 14.2929 14.7071C14.1054 14.5196 14 14.2652 14 14C14 13.7348 14.1054 13.4804 14.2929 13.2929C14.4804 13.1054 14.7348 13 15 13C15.2652 13 15.5196 13.1054 15.7071 13.2929C15.8946 13.4804 16 13.7348 16 14C16 14.2652 15.8946 14.5196 15.7071 14.7071C15.5196 14.8946 15.2652 15 15 15Z",
                fill: "#05F364"
            })
        })
    });
};
/* harmony default export */ const SvgIcons_AboutDiscountSvg = (AboutDiscountSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/AboutCryptoSvg.tsx


const AboutCryptoSvg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 21,
        height: 21,
        viewBox: "0 0 21 21",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "Group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M10.9877 19.2266C10.6733 19.3479 10.325 19.3479 10.0106 19.2266C7.5551 18.2638 5.4467 16.5834 3.96029 14.4046C2.47389 12.2259 1.67846 9.64979 1.67773 7.01228V3.03585C1.67773 2.67592 1.82072 2.33072 2.07523 2.07621C2.32975 1.8217 2.67494 1.67871 3.03488 1.67871H17.9634C18.3234 1.67871 18.6686 1.8217 18.9231 2.07621C19.1776 2.33072 19.3206 2.67592 19.3206 3.03585V6.99871C19.3226 9.63853 18.5284 12.2176 17.0419 14.399C15.5553 16.5805 13.4454 18.2629 10.9877 19.2266Z",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector_2",
                    d: "M12.534 8.46436H8.46261C7.71308 8.46436 7.10547 9.07197 7.10547 9.8215V12.5358C7.10547 13.2853 7.71308 13.8929 8.46261 13.8929H12.534C13.2836 13.8929 13.8912 13.2853 13.8912 12.5358V9.8215C13.8912 9.07197 13.2836 8.46436 12.534 8.46436Z",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector_3",
                    d: "M12.5343 8.46463V7.10749C12.5343 6.84016 12.4817 6.57544 12.3794 6.32846C12.2771 6.08147 12.1271 5.85706 11.9381 5.66802C11.749 5.47899 11.5246 5.32904 11.2776 5.22674C11.0307 5.12443 10.7659 5.07178 10.4986 5.07178C10.2313 5.07178 9.96656 5.12443 9.71957 5.22674C9.47259 5.32904 9.24817 5.47899 9.05914 5.66802C8.8701 5.85706 8.72015 6.08147 8.61785 6.32846C8.51555 6.57544 8.46289 6.84016 8.46289 7.10749V8.46463",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })
            ]
        })
    });
};
/* harmony default export */ const SvgIcons_AboutCryptoSvg = (AboutCryptoSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/AboutSecureSvg.tsx


const AboutSecureSvg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 21,
        height: 21,
        viewBox: "0 0 21 21",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "Group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M10.9877 19.2266C10.6733 19.3479 10.325 19.3479 10.0106 19.2266C7.5551 18.2638 5.4467 16.5834 3.96029 14.4046C2.47389 12.2259 1.67846 9.64979 1.67773 7.01228V3.03585C1.67773 2.67592 1.82072 2.33072 2.07523 2.07621C2.32975 1.8217 2.67494 1.67871 3.03488 1.67871H17.9634C18.3234 1.67871 18.6686 1.8217 18.9231 2.07621C19.1776 2.33072 19.3206 2.67592 19.3206 3.03585V6.99871C19.3226 9.63853 18.5284 12.2176 17.0419 14.399C15.5553 16.5805 13.4454 18.2629 10.9877 19.2266Z",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector_2",
                    d: "M12.534 8.46436H8.46261C7.71308 8.46436 7.10547 9.07197 7.10547 9.8215V12.5358C7.10547 13.2853 7.71308 13.8929 8.46261 13.8929H12.534C13.2836 13.8929 13.8912 13.2853 13.8912 12.5358V9.8215C13.8912 9.07197 13.2836 8.46436 12.534 8.46436Z",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector_3",
                    d: "M12.5343 8.46463V7.10749C12.5343 6.84016 12.4817 6.57544 12.3794 6.32846C12.2771 6.08147 12.1271 5.85706 11.9381 5.66802C11.749 5.47899 11.5246 5.32904 11.2776 5.22674C11.0307 5.12443 10.7659 5.07178 10.4986 5.07178C10.2313 5.07178 9.96656 5.12443 9.71957 5.22674C9.47259 5.32904 9.24817 5.47899 9.05914 5.66802C8.8701 5.85706 8.72015 6.08147 8.61785 6.32846C8.51555 6.57544 8.46289 6.84016 8.46289 7.10749V8.46463",
                    stroke: "#05F364",
                    strokeWidth: "1.5",
                    strokeLinecap: "round",
                    strokeLinejoin: "round"
                })
            ]
        })
    });
};
/* harmony default export */ const SvgIcons_AboutSecureSvg = (AboutSecureSvg);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./app/(main)/about/page.tsx









const AboutPage = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Main_Banner, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-10 lg:px-24 xl:max-w-[1270px] 2xl:max-w-[1450px] lg:mx-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full flex flex-col gap-y-4 lg:flex-row lg:gap-y-0 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex-1",
                                children: "Image"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex-1 pt-8",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Main_AboutBlock, {
                                    title: "What is APK Xchange",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-sm lg:text-base",
                                        children: "ApkXchange is the ultimate destination for savvy shoppers looking to purchase gift cards at discounted rates. We offer a wide variety of gift cards, including popular brands like iTunes, Amazon, and more. What sets us apart is our commitment to providing the best deals, allowing you to buy a $100 iTunes gift card for as low as $80! But that's not all – we go beyond just buying gift cards. ApkXchange also offers a unique service to sell your gift cards for cryptocurrencies like Bitcoin or USDT, providing you with even more flexibility and value."
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full flex flex-col gap-y-8  mt-12 lg:flex-row lg:items-start lg:gap-x-24 lg:gap-y-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Main_AboutBlock, {
                                title: "Secure & Efficient",
                                icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_AboutSecureSvg, {}),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm lg:text-base",
                                    children: "Trust is paramount to us. Our secure system ensures your transactions are safe, and our fast processes enable quick and hassle-free buying and selling experiences."
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Main_AboutBlock, {
                                title: "Discounted Gift Cards",
                                buttonText: "Buy/Sell",
                                link: "/exhange/buy",
                                icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_AboutDiscountSvg, {}),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm lg:text-base",
                                    children: "ApkXchange is the go-to platform for finding gift cards at unbeatable prices. Save money while still enjoying your favorite brands and services"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Main_AboutBlock, {
                                title: "CryptoCurrency Trading",
                                buttonText: "Read More",
                                icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_AboutCryptoSvg, {}),
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-sm lg:text-base",
                                    children: "For those interested in the world of cryptocurrency, we offer a seamless way to acquire crypto by trading your gift cards, making it easy to enter the digital currency market."
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex  justify-center items-center mt-8 bg-[#353945] py-8 lg:bg-transparent ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/images/101.webp",
                            width: 200,
                            height: 150,
                            alt: "gift-image"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-base font-light",
                                children: "Join Us Today!"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm lg:text-xl font-bold",
                                children: "TRADE SECURE,"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm lg:text-xl font-bold",
                                children: "TRADE WITH TRUST"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(MainButton/* default */.Z, {
                                    buttonText: "Create Account",
                                    link: "/signup",
                                    className: "text-sm lg:text-base"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (AboutPage);


/***/ }),

/***/ 2138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34834);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const MainButton = ({ link, buttonText, className })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
        href: link ? link : "#",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: `text-white px-4 py-1  font-semibold  rounded-2xl bg-gradient-to-b from-[#587BF2] to-[#012B5B] ${className}`,
            children: buttonText
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainButton);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,8421,9103,3592,993,8245,1635,5516,4579], () => (__webpack_exec__(75670)));
module.exports = __webpack_exports__;

})();