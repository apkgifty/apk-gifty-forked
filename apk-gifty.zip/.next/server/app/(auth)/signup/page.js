(() => {
var exports = {};
exports.id = 2129;
exports.ids = [2129];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 23960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(auth)',
        {
        children: [
        'signup',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54960)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(auth)\\signup\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 32403)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(auth)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(auth)\\signup\\page.tsx"];
    
    const originalPathname = "/(auth)/signup/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 49436:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 20006))

/***/ }),

/***/ 20006:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Form_SignupForm)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/react-cookie/cjs/index.js
var cjs = __webpack_require__(15786);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/LockOpen.js
var LockOpen = __webpack_require__(27802);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/PersonOutline.js
var PersonOutline = __webpack_require__(75501);
// EXTERNAL MODULE: ./components/Form/FormComponents/ExternalLogins.tsx + 1 modules
var ExternalLogins = __webpack_require__(40323);
// EXTERNAL MODULE: ./components/Form/FormComponents/Switch.tsx + 1 modules
var Switch = __webpack_require__(50755);
// EXTERNAL MODULE: ./components/Form/FormComponents/FormHeader.tsx
var FormHeader = __webpack_require__(66255);
// EXTERNAL MODULE: ./components/Form/FormComponents/FormBody.tsx
var FormBody = __webpack_require__(20793);
// EXTERNAL MODULE: ./components/Form/FormComponents/FormFooter.tsx
var FormFooter = __webpack_require__(11709);
// EXTERNAL MODULE: ./components/Form/FormComponents/FormContainer.tsx
var FormContainer = __webpack_require__(46958);
// EXTERNAL MODULE: ./components/Form/FormComponents/Form.tsx + 2 modules
var Form = __webpack_require__(28578);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/EmailAtSvg.tsx


const EmailAtSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Frame",
                clipPath: "url(#clip0_502_12)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M20 12C19.9998 10.2169 19.4039 8.48494 18.3069 7.07919C17.2099 5.67345 15.6747 4.67448 13.9451 4.24094C12.2155 3.80739 10.3906 3.96411 8.76028 4.68621C7.12992 5.40831 5.78753 6.65439 4.94629 8.22659C4.10504 9.79879 3.81316 11.607 4.11699 13.364C4.42083 15.1211 5.30296 16.7262 6.62331 17.9246C7.94366 19.1231 9.62653 19.846 11.4047 19.9787C13.1829 20.1114 14.9544 19.6462 16.438 18.657L17.548 20.321C15.9062 21.4187 13.975 22.0032 12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12V13.5C22.0001 14.2488 21.7601 14.9778 21.3152 15.5801C20.8703 16.1823 20.244 16.626 19.5283 16.846C18.8126 17.066 18.0453 17.0507 17.3389 16.8023C16.6326 16.5539 16.0245 16.0855 15.604 15.466C14.9366 16.16 14.083 16.6465 13.1457 16.8671C12.2085 17.0877 11.2275 17.033 10.3206 16.7096C9.41366 16.3861 8.61943 15.8077 8.03331 15.0438C7.44718 14.2799 7.09408 13.363 7.01644 12.4033C6.9388 11.4436 7.13991 10.4819 7.59562 9.63367C8.05133 8.78549 8.74225 8.08692 9.58537 7.6219C10.4285 7.15688 11.3879 6.94519 12.3485 7.01227C13.309 7.07934 14.2297 7.42232 15 8H17V13.5C17 13.8978 17.158 14.2794 17.4393 14.5607C17.7206 14.842 18.1022 15 18.5 15C18.8978 15 19.2794 14.842 19.5607 14.5607C19.842 14.2794 20 13.8978 20 13.5V12ZM12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_12",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_EmailAtSvg = (EmailAtSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/ReferralSvg.tsx


const ReferralSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 25,
        height: 25,
        viewBox: "0 0 24 27",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Referal-Code",
                clipPath: "url(#clip0_101_4437)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M9.47153 18.3748C8.08299 17.3195 7.04228 15.8153 6.50016 14.0801C5.95805 12.3448 5.9427 10.4686 6.45633 8.72334C6.96996 6.97804 7.9859 5.4543 9.35695 4.37287C10.728 3.29144 12.383 2.7085 14.082 2.7085C15.7811 2.7085 17.4361 3.29144 18.8071 4.37287C20.1782 5.4543 21.1941 6.97804 21.7077 8.72334C22.2214 10.4686 22.206 12.3448 21.6639 14.0801C21.1218 15.8153 20.0811 17.3195 18.6925 18.3748L20.7755 23.5042C20.809 23.5863 20.8229 23.6761 20.816 23.7655C20.8091 23.8549 20.7816 23.941 20.736 24.016C20.6904 24.091 20.6282 24.1526 20.5549 24.1951C20.4817 24.2377 20.3997 24.2598 20.3165 24.2596H7.84653C7.76345 24.2598 7.68164 24.2376 7.60851 24.1951C7.53538 24.1526 7.47322 24.0911 7.42766 24.0163C7.3821 23.9414 7.35458 23.8555 7.34757 23.7663C7.34056 23.677 7.3543 23.5874 7.38753 23.5053L9.47053 18.3748H9.47153ZM16.2065 17.628L17.5385 16.6139C18.5803 15.8227 19.3611 14.6947 19.768 13.3932C20.1749 12.0917 20.1867 10.6844 19.8016 9.37518C19.4165 8.066 18.6545 6.92297 17.6262 6.11173C16.5978 5.30049 15.3565 4.86319 14.082 4.86319C12.8076 4.86319 11.5662 5.30049 10.5379 6.11173C9.50953 6.92297 8.7476 8.066 8.3625 9.37518C7.9774 10.6844 7.98915 12.0917 8.39603 13.3932C8.80292 14.6947 9.58381 15.8227 10.6255 16.6139L11.9565 17.628L10.1395 22.1044H18.0235L16.2065 17.628ZM10.2005 12.3735L12.1405 11.8508C12.2482 12.3178 12.4978 12.7326 12.8495 13.029C13.2013 13.3254 13.635 13.4865 14.0815 13.4865C14.5281 13.4865 14.9618 13.3254 15.3135 13.029C15.6653 12.7326 15.9149 12.3178 16.0225 11.8508L17.9625 12.3735C17.745 13.3051 17.245 14.1317 16.542 14.7223C15.8389 15.3129 14.973 15.6337 14.0815 15.6337C13.1901 15.6337 12.3242 15.3129 11.6211 14.7223C10.918 14.1317 10.4181 13.3051 10.2005 12.3735Z",
                    fill: "#C4C4C4"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_101_4437",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: "23.5355",
                        height: "25.8629",
                        fill: "white",
                        transform: "translate(0.015625 0.552246)"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_ReferralSvg = (ReferralSvg);

;// CONCATENATED MODULE: ./components/Form/SignupForm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 













const fields = [
    {
        type: "text",
        placeholder: "username",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(PersonOutline/* default */.Z, {}),
        config: {
            required: true
        },
        name: "firstname"
    },
    {
        type: "email",
        placeholder: "Email",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_EmailAtSvg, {}),
        config: {
            required: true
        },
        name: "email"
    },
    {
        type: "password",
        placeholder: "Password",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(LockOpen/* default */.Z, {}),
        config: {
            required: true
        },
        name: "password"
    },
    {
        type: "text",
        placeholder: "Referral (Optional)",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_ReferralSvg, {}),
        config: {
            required: false
        },
        name: "referral"
    }
];
const SignupForm = ()=>{
    const [cookies, setCookie] = (0,cjs.useCookies)([
        "access"
    ]);
    const router = (0,navigation.useRouter)();
    const afterSubmit = (data)=>{
        if (data?.data?.token) {
            console.log(data);
            console.log(data.data.token);
            setCookie("access", data.data.token);
            router.push("/dashboard/exchange/buy");
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FormContainer/* default */.Z, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(FormHeader/* default */.Z, {
                title: "Create Your Account",
                subtitle: "Setting up an account takes less than 1 minute"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(FormBody/* default */.Z, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Switch["default"], {
                        items: [
                            {
                                label: "Login",
                                url: "login"
                            },
                            {
                                label: "Signup",
                                url: "signup"
                            }
                        ],
                        backgroundColor: "bg-tertiary"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Form/* default */.Z, {
                        fields: fields,
                        redirectUrl: "/dashboard/exchange/buy",
                        endpoint: "/api/register",
                        afterSubmit: afterSubmit
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FormFooter/* default */.Z, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ExternalLogins/* default */.Z, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Form_SignupForm = (SignupForm);


/***/ }),

/***/ 54960:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Form/SignupForm.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Form\SignupForm.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const SignupForm = (__default__);
;// CONCATENATED MODULE: ./app/(auth)/signup/page.tsx


const SignupPage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(SignupForm, {})
    });
};
/* harmony default export */ const page = (SignupPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,8421,9103,3592,8245,248,1543,3450,2916,1635,5516,9869,3874,8578,755,7502], () => (__webpack_exec__(23960)));
module.exports = __webpack_exports__;

})();