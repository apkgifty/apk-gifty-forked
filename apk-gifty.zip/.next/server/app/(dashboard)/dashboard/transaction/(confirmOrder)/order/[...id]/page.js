(() => {
var exports = {};
exports.id = 879;
exports.ids = [879];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 14300:
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ 32081:
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ 6113:
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 41808:
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 24404:
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 82098:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'dashboard',
        {
        children: [
        'transaction',
        {
        children: [
        '(confirmOrder)',
        {
        children: [
        'order',
        {
        children: [
        '[...id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56589)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\transaction\\(confirmOrder)\\order\\[...id]\\page.tsx"],
          
        }]
      },
        {
          'error': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 47388)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\transaction\\(confirmOrder)\\order\\[...id]\\error.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42981)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\transaction\\(confirmOrder)\\order\\[...id]\\page.tsx"];
    
    const originalPathname = "/(dashboard)/dashboard/transaction/(confirmOrder)/order/[...id]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 75446:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const actions = {
'be506aa90c603940497478bb1e6321f49c92cc30': () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 56589)).then(mod => mod["$$ACTION_1"]),
}

async function endpoint(id, ...args) {
  const action = await actions[id]()
  return action.apply(null, args)
}

// Using CJS to avoid this to be tree-shaken away due to unused exports.
module.exports = {
  'be506aa90c603940497478bb1e6321f49c92cc30': endpoint.bind(null, 'be506aa90c603940497478bb1e6321f49c92cc30'),
}


/***/ }),

/***/ 28905:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 63777))

/***/ }),

/***/ 31174:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62493))

/***/ }),

/***/ 63777:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const Error = ({ error, reset })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            children: "There’s no order"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Error);


/***/ }),

/***/ 62493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Clients_ConfirmOrder)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./components/Dashboard/DashUtils/Countdown.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

const CountdownTimer = ({ stopTime })=>{
    const targetTime = new Date(stopTime).getTime();
    const [timeLeft, setTimeLeft] = (0,react_experimental_.useState)(getTimeRemaining());
    (0,react_experimental_.useEffect)(()=>{
        const interval = setInterval(()=>{
            const timeRemaining = getTimeRemaining();
            setTimeLeft(timeRemaining);
            if (timeRemaining.total <= 0) {
                clearInterval(interval);
                handleCountdownEnd();
            }
        }, 1000);
        return ()=>clearInterval(interval);
    }, [
        stopTime
    ]);
    function getTimeRemaining() {
        const currentTime = new Date().getTime();
        const timeDifference = targetTime - currentTime;
        if (timeDifference <= 0) {
            return {
                total: 0,
                days: 0,
                hours: 0,
                minutes: 0,
                seconds: 0
            };
        }
        const oneSecond = 1000;
        const oneMinute = oneSecond * 60;
        const oneHour = oneMinute * 60;
        const oneDay = oneHour * 24;
        const days = Math.floor(timeDifference / oneDay);
        const hours = Math.floor(timeDifference % oneDay / oneHour);
        const minutes = Math.floor(timeDifference % oneHour / oneMinute);
        const seconds = Math.floor(timeDifference % oneMinute / oneSecond);
        return {
            total: timeDifference,
            days,
            hours,
            minutes,
            seconds
        };
    }
    function formatTime(value) {
        return value < 10 ? `0${value}` : value;
    }
    function handleCountdownEnd() {
        // Add your code here to handle the action when the countdown ends
        console.log("Countdown has ended. Do something here.");
    }
    console.log(stopTime);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            timeLeft.total > 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "space-x-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-2xl font-bold text-violet-500",
                        children: formatTime(timeLeft.minutes)
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-2xl font-bold text-violet-500",
                        children: ":"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-2xl font-bold text-violet-500",
                        children: formatTime(timeLeft.seconds)
                    })
                ]
            }),
            timeLeft.total < 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: "Countdown has ended."
            })
        ]
    });
};
/* harmony default export */ const Countdown = (CountdownTimer);

// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogContentText/index.js
var DialogContentText = __webpack_require__(67641);
var DialogContentText_default = /*#__PURE__*/__webpack_require__.n(DialogContentText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogTitle/index.js
var DialogTitle = __webpack_require__(2097);
var DialogTitle_default = /*#__PURE__*/__webpack_require__.n(DialogTitle);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(98511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Dialog/index.js
var Dialog = __webpack_require__(33429);
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogActions/index.js
var DialogActions = __webpack_require__(9268);
var DialogActions_default = /*#__PURE__*/__webpack_require__.n(DialogActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogContent/index.js
var DialogContent = __webpack_require__(15381);
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent);
;// CONCATENATED MODULE: ./components/UI/Dialog/Dialog.tsx








const DisplayDialog = ({ open, handleClose, title, children, buttonText })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dialog_default()), {
        open: open,
        onClose: handleClose,
        "aria-labelledby": "alert-dialog-title",
        "aria-describedby": "alert-dialog-description",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((DialogTitle_default()), {
                id: "alert-dialog-title",
                children: title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((DialogContent_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((DialogContentText_default()), {
                    id: "alert-dialog-description",
                    children: children
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((DialogActions_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    onClick: handleClose,
                    autoFocus: true,
                    children: buttonText
                })
            })
        ]
    });
};
/* harmony default export */ const Dialog_Dialog = (DisplayDialog);

// EXTERNAL MODULE: ./node_modules/pusher-js/dist/node/pusher.js
var node_pusher = __webpack_require__(3261);
var pusher_default = /*#__PURE__*/__webpack_require__.n(node_pusher);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/EmotionSvg.tsx


const EmotionSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "emotion-happy-line 1",
                clipPath: "url(#clip0_264_4029)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22ZM12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20ZM7 13H9C9 13.7956 9.31607 14.5587 9.87868 15.1213C10.4413 15.6839 11.2044 16 12 16C12.7956 16 13.5587 15.6839 14.1213 15.1213C14.6839 14.5587 15 13.7956 15 13H17C17 14.3261 16.4732 15.5979 15.5355 16.5355C14.5979 17.4732 13.3261 18 12 18C10.6739 18 9.40215 17.4732 8.46447 16.5355C7.52678 15.5979 7 14.3261 7 13ZM8 11C7.60218 11 7.22064 10.842 6.93934 10.5607C6.65804 10.2794 6.5 9.89782 6.5 9.5C6.5 9.10218 6.65804 8.72064 6.93934 8.43934C7.22064 8.15804 7.60218 8 8 8C8.39782 8 8.77936 8.15804 9.06066 8.43934C9.34196 8.72064 9.5 9.10218 9.5 9.5C9.5 9.89782 9.34196 10.2794 9.06066 10.5607C8.77936 10.842 8.39782 11 8 11ZM16 11C15.6022 11 15.2206 10.842 14.9393 10.5607C14.658 10.2794 14.5 9.89782 14.5 9.5C14.5 9.10218 14.658 8.72064 14.9393 8.43934C15.2206 8.15804 15.6022 8 16 8C16.3978 8 16.7794 8.15804 17.0607 8.43934C17.342 8.72064 17.5 9.10218 17.5 9.5C17.5 9.89782 17.342 10.2794 17.0607 10.5607C16.7794 10.842 16.3978 11 16 11Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_264_4029",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_EmotionSvg = (EmotionSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/PaperPlaneSvg.tsx


const PaperPlaneSvg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "vuesax/broken/send-2",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                id: "send-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        id: "Vector",
                        d: "M15.8897 3.49015C19.6997 2.22015 21.7697 4.30015 20.5097 8.11015L17.6797 16.6002C15.7797 22.3102 12.6597 22.3102 10.7597 16.6002L9.91969 14.0802L7.39969 13.2402C1.68969 11.3402 1.68969 8.23015 7.39969 6.32015L11.9997 4.79015",
                        stroke: "white",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        id: "Vector_2",
                        d: "M10.1094 13.6496L13.6894 10.0596",
                        stroke: "white",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const SvgIcons_PaperPlaneSvg = (PaperPlaneSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/AddSvg.tsx


const AddSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Frame",
                clipPath: "url(#clip0_264_4033)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M11 11V7H13V11H17V13H13V17H11V13H7V11H11ZM12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12C22 17.523 17.523 22 12 22ZM12 20C14.1217 20 16.1566 19.1571 17.6569 17.6569C19.1571 16.1566 20 14.1217 20 12C20 9.87827 19.1571 7.84344 17.6569 6.34315C16.1566 4.84285 14.1217 4 12 4C9.87827 4 7.84344 4.84285 6.34315 6.34315C4.84285 7.84344 4 9.87827 4 12C4 14.1217 4.84285 16.1566 6.34315 17.6569C7.84344 19.1571 9.87827 20 12 20Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_264_4033",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_AddSvg = (AddSvg);

;// CONCATENATED MODULE: ./components/Dashboard/DashUtils/Chat.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const pusherKey = process.env.NEXT_PUBLIC_PUSHER_APP_KEY;
const cluster = process.env.NEXT_PUBLIC_PUSHER_APP_CLUSTER;
const Chat = ({ status, chat })=>{
    console.log(chat);
    //   console.log(pusherKey, cluster);
    console.log(status);
    const [chats, setChats] = (0,react_experimental_.useState)([]);
    const [pusher, setPusher] = (0,react_experimental_.useState)(null);
    const [messageToSend, setMessageToSend] = (0,react_experimental_.useState)("");
    (0,react_experimental_.useEffect)(()=>{
        const pusher = new (pusher_default())("e597b63b0a16d6c4a2c6", {
            cluster: "mt1",
            channelAuthorization: {
                endpoint: "https://backend.apkxchange.com/api/chat/auth",
                transport: "ajax",
                headers: {
                    Accept: "application/json",
                    Authorization: `Bearer ${"11|ITqRVhblUMf8e3JBXQ1szGn22e37TsWI8x5shZ7F"}`
                }
            },
            userAuthentication: {
                endpoint: "https://backend.apkxchange.com/api/chat/auth",
                transport: "ajax",
                headers: {
                    Accept: "application/json",
                    Authorization: `Bearer 11|ITqRVhblUMf8e3JBXQ1szGn22e37TsWI8x5shZ7F`
                }
            }
        });
        pusher.signin();
        pusher.connection.bind("error", (err)=>{
            if (err) {
                console.log(err);
            }
        });
        setPusher(pusher);
        const channel = pusher.subscribe("private-chatify.2");
        console.log(channel);
        pusher.allChannels().forEach((channel)=>console.log(channel));
        channel.bind("messaging", (data)=>{
            console.log(data);
            setChats((prevState)=>[
                    ...prevState,
                    {
                        sender: data.sender,
                        message: data.message
                    }
                ]);
        });
        return ()=>pusher.unsubscribe("channel-name");
    }, []);
    console.log(chats);
    const handleReply = async ()=>{
        await axios/* default */.Z.post("/api/pusher", {
            sender: "ylee",
            message: "What's up"
        });
    };
    // const handleChatSubmit = () => {};
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: status.toString() === "1" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full   flex-grow flex flex-col  h-[750px] relative mt-20 py-4  lg:border-l-2 lg:border-tertiary lg:w-[35%] lg:mt-0 lg:h-full ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-full flex flex-1 justify-between px-4  ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-x-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "object-cover w-10 h-10 rounded-lg",
                                    src: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=faceare&facepad=3&w=688&h=688&q=100",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "font-semibold",
                                        children: "Tom Gravesen"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-gray-500 text-sm",
                                        children: "Online"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "px-4 h-full flex-2 overflow-scroll ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full flex justify-center mt-10",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xs font-light",
                                children: "Today, 8:26 AM"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "my-10",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Hello Linh!"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "my-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "I really love your work, great job"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-gray-400 text-xs mt-6 block",
                                    children: "03:49PM"
                                })
                            ]
                        }),
                        chats.map((chat)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                dangerouslySetInnerHTML: {
                                    __html: chat.message
                                }
                            }, chat.message))
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full  bg-secondary  flex flex-1 py-6 items-center justify-between px-4   ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-x-2 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "px-3 py-3 bg-primary rounded-lg ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_EmotionSvg, {})
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "px-3 py-3 bg-primary rounded-lg ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_AddSvg, {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full  mx-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                placeholder: "Type Something...",
                                className: "bg-transparent text-gray-500 text-sm w-full outline-none"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "px-2 py-2 bg-[#7995f5] rounded-lg ",
                            onClick: handleReply,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_PaperPlaneSvg, {})
                        })
                    ]
                })
            ]
        }) : null
    });
};
/* harmony default export */ const DashUtils_Chat = (Chat);

;// CONCATENATED MODULE: ./components/Clients/ConfirmOrder.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






// const getCreateUser = async () => {
//   const response = await axios.put(
//     "https://api.chatengine.io/users/",
//     {
//       username: "gg@g.com",
//       secret: "gg@g.com",
//       email: "gg@g.com",
//     },
//     {
//       headers: {
//         "Private-KEY": "6a558d7d-b985-4e25-a83f-2d3f4d97074e",
//       },
//     }
//   );
//   return response.data;
// };
// const getCreateChat = async () => {
//   const response = await axios.put(
//     "https://api.chatengine.io/chats/",
//     {
//       usernames: ["huntdavid175@gmail.com", "gg@g.com"],
//       is_direct_chat: true,
//     },
//     {
//       headers: {
//         "Private-KEY": "6a558d7d-b985-4e25-a83f-2d3f4d97074e",
//       },
//     }
//   );
//   return response.data;
// };
const sendRequest = async (id)=>{
    let data = JSON.stringify({
        id
    });
    let config = {
        method: "POST",
        maxBodyLength: Infinity,
        url: "/api/notify-seller",
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json"
        },
        data: data
    };
    try {
        const response = await (0,axios/* default */.Z)(config);
        console.log(response.data);
        return response.data;
    } catch (error) {
        console.log(error);
    }
};
const ConfirmOrder = ({ paymentMethods, orderData })=>{
    const { price, description, quantity, id, instructions, status, notify_seller, processing_end_time } = orderData;
    const [openDialog, setOpenDialog] = (0,react_experimental_.useState)(false);
    const [statuss, setStatuss] = (0,react_experimental_.useState)(status);
    const [stop, setStop] = (0,react_experimental_.useState)(processing_end_time);
    const [chat, setChat] = (0,react_experimental_.useState)(null);
    const paths = (0,navigation.usePathname)().split("/");
    const pathname = paths[paths.length - 1];
    console.log(paymentMethods);
    const handleSubmit = async ()=>{
        const res = await sendRequest(id);
        console.log(res.data);
        setStatuss(res.data.status);
        setStop(res.data.processing_end_time);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-2 lg:px-10 w-full lg:w-[60%] lg:overflow-y-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-10 pb-8 flex justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-sm lg:text-lg font-semibold",
                                children: "Confirm order information"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: " text-sm lg:text-base cursor-pointer text-red-400",
                                onClick: ()=>setOpenDialog(true),
                                children: "Read order info"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-x-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-xs lg:text-base text-gray-400",
                                children: [
                                    pathname === "buy" ? "Quantity" : pathname === "sell" ? "Value " : null,
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-white",
                                        children: [
                                            ":- ",
                                            quantity
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-xs lg:text-base text-gray-400",
                                children: [
                                    "Amount To Pay ",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-white",
                                        children: [
                                            ":- $",
                                            price
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-14",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h4", {
                                className: "text-sm lg:text-lg font-semibold",
                                children: [
                                    "Payment Instructions",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: " mt-6 flex flex-col lg:flex-row lg:justify-between",
                                children: paymentMethods.map((method)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "space-y-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                        className: "inline-block text-blue-700 px-3 py-1 border-2 border-blue-700 rounded-lg",
                                                        children: method.channel
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "inline-block px-3 py-1 text-green-600 border-2 border-green-600 rounded-lg",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {}),
                                                            " ",
                                                            method.body
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "inline-block px-3 py-1 text-green-600 border-2 border-green-600 rounded-lg",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "text-white",
                                                                children: "Name:"
                                                            }),
                                                            " ",
                                                            method.sub_text
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    }, method.id))
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-12",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-sm lg:text-base",
                            children: "After Transfering the amount, click on the Transfered button"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-8 space-y-4 flex flex-col lg:flex-row lg:space-x-6 lg:space-y-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-full text-sm px-4 py-2 bg-[#7995f5] rounded-lg lg:w-auto disabled:bg-gray-700 disabled:cursor-not-allowed ",
                                onClick: handleSubmit,
                                disabled: statuss.toString() === "1",
                                children: pathname === "buy" ? "Paid " : pathname === "sell" ? "Payment made" : null
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-full text-sm px-4 py-2 lg:w-auto",
                                children: "Cancel Transfer"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-10 flex items-center gap-x-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Payment time:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Countdown, {
                                stopTime: stop
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(DashUtils_Chat, {
                status: statuss,
                chat: chat
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Dialog_Dialog, {
                open: openDialog,
                handleClose: ()=>setOpenDialog(false),
                title: "Order Instructions",
                buttonText: "Close",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                    className: "list-decimal pl-2 space-y-4 text-gray-700",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: "Remember every trade that occurs on our platform attracts a fee of 1% on every amount. All trades less than $100 will attract a $1 fee on it."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: "Before you proceed Kindly make sure you’ve read through our Trade Guidelines before proceeding."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: "The card or the code of your order will be uploaded in the chat section of this trade. Make sure to use the card within the timeframe provided for you."
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Clients_ConfirmOrder = (ConfirmOrder);


/***/ }),

/***/ 47388:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\app\(dashboard)\dashboard\transaction\(confirmOrder)\order\[...id]\error.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 56589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  $$ACTION_1: () => (/* binding */ $$ACTION_1),
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-proxy.js
var action_proxy = __webpack_require__(47404);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(66558);
// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(63919);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Clients/ConfirmOrder.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Clients\ConfirmOrder.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const ConfirmOrder = (__default__);
;// CONCATENATED MODULE: ./app/(dashboard)/dashboard/transaction/(confirmOrder)/order/[...id]/page.tsx
/* __next_internal_action_entry_do_not_use__ $$ACTION_1 */ 




const runAction = ($$ACTION_0 = async (...args)=>$$ACTION_1.apply(null, ($$ACTION_0.$$bound || []).concat(args)), (0,action_proxy/* default */.Z)("be506aa90c603940497478bb1e6321f49c92cc30", null, $$ACTION_0, $$ACTION_1), $$ACTION_0);
var $$ACTION_1 = async ()=>{
    console.log("It happened");
};
var $$ACTION_0;
const fetchOrder = async (id, token)=>{
    try {
        const response = await axios/* default */.Z.get(`https://backend.apkxchange.com/api/order/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error) {}
};
const fetchPaymentMethods = async (token)=>{
    try {
        const response = await axios/* default */.Z.get("https://backend.apkxchange.com/api/paymentInstructions", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error) {}
};
const ConfirmOrderPage = async ({ searchParams })=>{
    const cookieStore = (0,headers.cookies)();
    const accessToken = cookieStore.get("access")?.value;
    const id = searchParams.pid;
    if (!id) throw new Error("No order with that id");
    const [orderData, paymentMethods] = await Promise.all([
        fetchOrder(id, accessToken),
        fetchPaymentMethods(accessToken)
    ]);
    // console.log(orderData);
    // console.log(paymentMethods);
    const { price, processing_end_time, status } = orderData?.data;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full bg-secondary px-4 flex flex-col  text-white pb-32 lg:flex-row lg:px-0 lg:h-screen lg:pb-0 lg:overflow-hidden",
        children: /*#__PURE__*/ jsx_runtime_.jsx(ConfirmOrder, {
            // token={accessToken!}
            orderData: orderData.data,
            paymentMethods: paymentMethods.data
        })
    });
};
/* harmony default export */ const page = (ConfirmOrderPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9837,9967,3592,993,6558,248,5522,4621,1635,8732], () => (__webpack_exec__(82098)));
module.exports = __webpack_exports__;

})();