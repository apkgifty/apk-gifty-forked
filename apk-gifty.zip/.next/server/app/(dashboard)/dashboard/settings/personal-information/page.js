(() => {
var exports = {};
exports.id = 4078;
exports.ids = [4078];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 69835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'dashboard',
        {
        children: [
        'settings',
        {
        children: [
        'personal-information',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10666)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\settings\\personal-information\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 39621)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\settings\\layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42981)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\settings\\personal-information\\page.tsx"];
    
    const originalPathname = "/(dashboard)/dashboard/settings/personal-information/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 94335:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 73874))

/***/ }),

/***/ 10666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(63919);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Form/FormComponents/FormInput.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Form\FormComponents\FormInput.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const FormInput = (__default__);
// EXTERNAL MODULE: ./components/UI/SvgIcons/CurrencyIconSvg.tsx
var CurrencyIconSvg = __webpack_require__(84743);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/EditIconSvg.tsx


const EditIconSvg = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: 20,
        height: 21,
        viewBox: "0 0 20 21",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "vuesax/linear/edit",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                id: "edit",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        id: "Vector",
                        d: "M9.16699 2.16699L7.50033 2.16699C3.33366 2.16699 1.66699 3.83366 1.66699 8.00033L1.66699 13.0003C1.66699 17.167 3.33366 18.8337 7.50033 18.8337H12.5003C16.667 18.8337 18.3337 17.167 18.3337 13.0003V11.3337",
                        stroke: "white",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        id: "Vector_2",
                        d: "M13.3666 3.01639L6.7999 9.58306C6.5499 9.83306 6.2999 10.3247 6.2499 10.6831L5.89157 13.1914C5.75823 14.0997 6.3999 14.7331 7.30823 14.6081L9.81657 14.2497C10.1666 14.1997 10.6582 13.9497 10.9166 13.6997L17.4832 7.13306C18.6166 5.99972 19.1499 4.68306 17.4832 3.01639C15.8166 1.34972 14.4999 1.88306 13.3666 3.01639Z",
                        stroke: "white",
                        strokeWidth: "1.5",
                        strokeMiterlimit: 10,
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        id: "Vector_3",
                        d: "M12.4248 3.95801C12.9831 5.94967 14.5415 7.50801 16.5415 8.07467",
                        stroke: "white",
                        strokeWidth: "1.5",
                        strokeMiterlimit: 10,
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const SvgIcons_EditIconSvg = (EditIconSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/EmailAtSvg.tsx


const EmailAtSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Frame",
                clipPath: "url(#clip0_502_12)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M20 12C19.9998 10.2169 19.4039 8.48494 18.3069 7.07919C17.2099 5.67345 15.6747 4.67448 13.9451 4.24094C12.2155 3.80739 10.3906 3.96411 8.76028 4.68621C7.12992 5.40831 5.78753 6.65439 4.94629 8.22659C4.10504 9.79879 3.81316 11.607 4.11699 13.364C4.42083 15.1211 5.30296 16.7262 6.62331 17.9246C7.94366 19.1231 9.62653 19.846 11.4047 19.9787C13.1829 20.1114 14.9544 19.6462 16.438 18.657L17.548 20.321C15.9062 21.4187 13.975 22.0032 12 22C6.477 22 2 17.523 2 12C2 6.477 6.477 2 12 2C17.523 2 22 6.477 22 12V13.5C22.0001 14.2488 21.7601 14.9778 21.3152 15.5801C20.8703 16.1823 20.244 16.626 19.5283 16.846C18.8126 17.066 18.0453 17.0507 17.3389 16.8023C16.6326 16.5539 16.0245 16.0855 15.604 15.466C14.9366 16.16 14.083 16.6465 13.1457 16.8671C12.2085 17.0877 11.2275 17.033 10.3206 16.7096C9.41366 16.3861 8.61943 15.8077 8.03331 15.0438C7.44718 14.2799 7.09408 13.363 7.01644 12.4033C6.9388 11.4436 7.13991 10.4819 7.59562 9.63367C8.05133 8.78549 8.74225 8.08692 9.58537 7.6219C10.4285 7.15688 11.3879 6.94519 12.3485 7.01227C13.309 7.07934 14.2297 7.42232 15 8H17V13.5C17 13.8978 17.158 14.2794 17.4393 14.5607C17.7206 14.842 18.1022 15 18.5 15C18.8978 15 19.2794 14.842 19.5607 14.5607C19.842 14.2794 20 13.8978 20 13.5V12ZM12 9C11.2044 9 10.4413 9.31607 9.87868 9.87868C9.31607 10.4413 9 11.2044 9 12C9 12.7956 9.31607 13.5587 9.87868 14.1213C10.4413 14.6839 11.2044 15 12 15C12.7956 15 13.5587 14.6839 14.1213 14.1213C14.6839 13.5587 15 12.7956 15 12C15 11.2044 14.6839 10.4413 14.1213 9.87868C13.5587 9.31607 12.7956 9 12 9Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_12",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_EmailAtSvg = (EmailAtSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/EyeIconSvg.tsx


const EyeIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "eye-line 1",
                clipPath: "url(#clip0_502_347)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M11.9997 3C17.3917 3 21.8777 6.88 22.8187 12C21.8787 17.12 17.3917 21 11.9997 21C6.60766 21 2.12166 17.12 1.18066 12C2.12066 6.88 6.60766 3 11.9997 3ZM11.9997 19C14.0391 18.9996 16.0181 18.3068 17.6125 17.0352C19.207 15.7635 20.3226 13.9883 20.7767 12C20.3209 10.0133 19.2046 8.24 17.6103 6.97003C16.016 5.70005 14.038 5.00853 11.9997 5.00853C9.96136 5.00853 7.98335 5.70005 6.38904 6.97003C4.79473 8.24 3.67843 10.0133 3.22266 12C3.67676 13.9883 4.79234 15.7635 6.38681 17.0352C7.98128 18.3068 9.9602 18.9996 11.9997 19ZM11.9997 16.5C10.8062 16.5 9.6616 16.0259 8.81768 15.182C7.97377 14.3381 7.49966 13.1935 7.49966 12C7.49966 10.8065 7.97377 9.66193 8.81768 8.81802C9.6616 7.97411 10.8062 7.5 11.9997 7.5C13.1931 7.5 14.3377 7.97411 15.1816 8.81802C16.0256 9.66193 16.4997 10.8065 16.4997 12C16.4997 13.1935 16.0256 14.3381 15.1816 15.182C14.3377 16.0259 13.1931 16.5 11.9997 16.5ZM11.9997 14.5C12.6627 14.5 13.2986 14.2366 13.7674 13.7678C14.2363 13.2989 14.4997 12.663 14.4997 12C14.4997 11.337 14.2363 10.7011 13.7674 10.2322C13.2986 9.76339 12.6627 9.5 11.9997 9.5C11.3366 9.5 10.7007 9.76339 10.2319 10.2322C9.76306 10.7011 9.49966 11.337 9.49966 12C9.49966 12.663 9.76306 13.2989 10.2319 13.7678C10.7007 14.2366 11.3366 14.5 11.9997 14.5Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_347",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_EyeIconSvg = (EyeIconSvg);

// EXTERNAL MODULE: ./components/UI/SvgIcons/KycIconSvg.tsx
var KycIconSvg = __webpack_require__(26860);
;// CONCATENATED MODULE: ./components/UI/SvgIcons/MailIconSvg.tsx


const MailIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "mail-open-line 1",
                clipPath: "url(#clip0_502_1417)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M2.243 6.85448L11.49 1.31048C11.6454 1.21723 11.8233 1.16797 12.0045 1.16797C12.1857 1.16797 12.3636 1.21723 12.519 1.31048L21.757 6.85548C21.8311 6.89989 21.8925 6.96276 21.9351 7.03794C21.9776 7.11313 22 7.19807 22 7.28448V20.0005C22 20.2657 21.8946 20.5201 21.7071 20.7076C21.5196 20.8951 21.2652 21.0005 21 21.0005H3C2.73478 21.0005 2.48043 20.8951 2.29289 20.7076C2.10536 20.5201 2 20.2657 2 20.0005V7.28348C1.99998 7.19707 2.02236 7.11213 2.06495 7.03694C2.10753 6.96176 2.16888 6.89889 2.243 6.85448ZM4 8.13348V19.0005H20V8.13248L12.004 3.33248L4 8.13248V8.13348ZM12.06 13.6985L17.356 9.23548L18.644 10.7655L12.074 16.3025L5.364 10.7725L6.636 9.22848L12.06 13.6985Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_1417",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_MailIconSvg = (MailIconSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/MapIconSvg.tsx


const MapIconSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "map-pin-line 1",
                clipPath: "url(#clip0_502_77)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M12 20.8999L16.95 15.9499C17.9289 14.9709 18.5955 13.7236 18.8656 12.3658C19.1356 11.0079 18.9969 9.60052 18.4671 8.32148C17.9373 7.04244 17.04 5.94923 15.8889 5.18009C14.7378 4.41095 13.3844 4.00043 12 4.00043C10.6156 4.00043 9.26222 4.41095 8.11109 5.18009C6.95996 5.94923 6.06275 7.04244 5.53292 8.32148C5.00308 9.60052 4.86442 11.0079 5.13445 12.3658C5.40449 13.7236 6.07111 14.9709 7.05 15.9499L12 20.8999ZM12 23.7279L5.636 17.3639C4.37734 16.1052 3.52019 14.5016 3.17293 12.7558C2.82567 11.0099 3.00391 9.20035 3.6851 7.55582C4.36629 5.91129 5.51984 4.50569 6.99988 3.51677C8.47992 2.52784 10.22 2 12 2C13.78 2 15.5201 2.52784 17.0001 3.51677C18.4802 4.50569 19.6337 5.91129 20.3149 7.55582C20.9961 9.20035 21.1743 11.0099 20.8271 12.7558C20.4798 14.5016 19.6227 16.1052 18.364 17.3639L12 23.7279ZM12 12.9999C12.5304 12.9999 13.0391 12.7892 13.4142 12.4141C13.7893 12.0391 14 11.5304 14 10.9999C14 10.4695 13.7893 9.96078 13.4142 9.58571C13.0391 9.21064 12.5304 8.99992 12 8.99992C11.4696 8.99992 10.9609 9.21064 10.5858 9.58571C10.2107 9.96078 10 10.4695 10 10.9999C10 11.5304 10.2107 12.0391 10.5858 12.4141C10.9609 12.7892 11.4696 12.9999 12 12.9999ZM12 14.9999C10.9391 14.9999 9.92172 14.5785 9.17158 13.8283C8.42143 13.0782 8 12.0608 8 10.9999C8 9.93906 8.42143 8.92164 9.17158 8.17149C9.92172 7.42135 10.9391 6.99992 12 6.99992C13.0609 6.99992 14.0783 7.42135 14.8284 8.17149C15.5786 8.92164 16 9.93906 16 10.9999C16 12.0608 15.5786 13.0782 14.8284 13.8283C14.0783 14.5785 13.0609 14.9999 12 14.9999Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_502_77",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_MapIconSvg = (MapIconSvg);

;// CONCATENATED MODULE: ./components/UI/SvgIcons/PhoneSvg.tsx


const PhoneSvg = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                id: "Frame",
                clipPath: "url(#clip0_264_4013)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    id: "Vector",
                    d: "M9.366 10.682C10.3043 12.3305 11.6695 13.6957 13.318 14.634L14.202 13.396C14.3442 13.1969 14.5543 13.0569 14.7928 13.0023C15.0313 12.9478 15.2814 12.9825 15.496 13.1C16.9103 13.8729 18.4722 14.3378 20.079 14.464C20.3298 14.4839 20.5638 14.5975 20.7345 14.7823C20.9052 14.9671 21 15.2094 21 15.461V19.923C21.0001 20.1706 20.9083 20.4094 20.7424 20.5932C20.5765 20.777 20.3483 20.8927 20.102 20.918C19.572 20.973 19.038 21 18.5 21C9.94 21 3 14.06 3 5.5C3 4.962 3.027 4.428 3.082 3.898C3.10725 3.6517 3.22298 3.42352 3.40679 3.25763C3.5906 3.09175 3.82941 2.99995 4.077 3H8.539C8.79056 2.99997 9.0329 3.09475 9.21768 3.26545C9.40247 3.43615 9.51613 3.67022 9.536 3.921C9.66222 5.52779 10.1271 7.08968 10.9 8.504C11.0175 8.71856 11.0522 8.96874 10.9977 9.2072C10.9431 9.44565 10.8031 9.65584 10.604 9.798L9.366 10.682ZM6.844 10.025L8.744 8.668C8.20478 7.50409 7.83535 6.26884 7.647 5H5.01C5.004 5.166 5.001 5.333 5.001 5.5C5 12.956 11.044 19 18.5 19C18.667 19 18.834 18.997 19 18.99V16.353C17.7312 16.1646 16.4959 15.7952 15.332 15.256L13.975 17.156C13.4287 16.9437 12.898 16.6931 12.387 16.406L12.329 16.373C10.3676 15.2567 8.74328 13.6324 7.627 11.671L7.594 11.613C7.30691 11.102 7.05628 10.5713 6.844 10.025Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_264_4013",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 24,
                        height: 24,
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SvgIcons_PhoneSvg = (PhoneSvg);

// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(66558);
;// CONCATENATED MODULE: ./app/(dashboard)/dashboard/settings/personal-information/page.tsx











// import axiosInstance from "@/utils/axios";

const PersonalInformationPage = async ()=>{
    const cookieStore = (0,headers.cookies)();
    const accessToken = cookieStore.get("access")?.value;
    let user;
    try {
        const res = await axios/* default */.Z.get("https://backend.apkxchange.com/api/profile", {
            headers: {
                Authorization: `Bearer ${accessToken}`
            }
        });
        console.log(res.data);
        user = res.data.data;
    } catch (error) {
        console.log(error);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full text-white pb-32",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex items-center justify-between pb-6 border-b-2 border-black",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-base font-semibold",
                        children: "My Profile"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "px-3 py-2 bg-primary rounded-lg flex items-center gap-x-3 cursor-pointer",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_EditIconSvg, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-sm lg:text-base",
                                children: "Edit"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-400 ",
                        children: "Personal Information"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap justify-between gap-y-4 mt-6 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(KycIconSvg/* default */.Z, {}),
                                    type: "text",
                                    placeholder: "First Name",
                                    name: "firstname",
                                    className: "bg-primary",
                                    defaultValue: user.firstname,
                                    readOnly: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(KycIconSvg/* default */.Z, {}),
                                    type: "text",
                                    placeholder: "Last Name",
                                    name: "lastname ",
                                    className: "bg-primary",
                                    readOnly: true
                                })
                            }),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_EyeIconSvg, {}),
                                    type: "text",
                                    placeholder: "Display Name",
                                    name: "displayname",
                                    className: "bg-primary",
                                    defaultValue: user.firstname,
                                    readOnly: true
                                })
                            }),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_EmailAtSvg, {}),
                                    type: "text",
                                    placeholder: "User Name",
                                    name: "username",
                                    className: "bg-primary",
                                    defaultValue: user.firstname,
                                    readOnly: true
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-400 ",
                        children: "Contact Info"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap justify-between gap-y-4 mt-6 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_MailIconSvg, {}),
                                    type: "text",
                                    placeholder: "Email Address",
                                    name: "email",
                                    className: "bg-primary",
                                    defaultValue: user.email,
                                    readOnly: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(CurrencyIconSvg/* default */.Z, {}),
                                    type: "text",
                                    placeholder: "Currency",
                                    name: "currency",
                                    className: "bg-primary",
                                    readOnly: true
                                })
                            }),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_MapIconSvg, {}),
                                    type: "text",
                                    placeholder: "Location",
                                    name: "location",
                                    className: "bg-primary",
                                    defaultValue: user.nationality,
                                    readOnly: true
                                })
                            }),
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full lg:w-[45%]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FormInput, {
                                    icon: /*#__PURE__*/ jsx_runtime_.jsx(SvgIcons_PhoneSvg, {}),
                                    type: "text",
                                    placeholder: "Phone Number",
                                    name: "phonenumber",
                                    className: "bg-primary",
                                    defaultValue: user.phone_number,
                                    readOnly: true
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex flex-col gap-y-4 justify-between items-center mt-10 py-8 border-t-2 border-black lg:flex-row lg:gap-y-0 ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full lg:w-[45%] space-y-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-gray-500 text-sm",
                                children: "Account created at:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-light",
                                children: "Tuesday - 2022 31 July"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col w-full lg:w-[45%] gap-y-2 lg:gap-x-4 lg:gap-y-0 lg:flex-row",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-full text-sm px-4 py-2 bg-secondary rounded-lg",
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "w-full text-sm px-4 py-2 bg-appviolet rounded-lg",
                                children: "Save Changes"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (PersonalInformationPage);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9967,993,6558,5522,1635,8732,3874,6502], () => (__webpack_exec__(69835)));
module.exports = __webpack_exports__;

})();