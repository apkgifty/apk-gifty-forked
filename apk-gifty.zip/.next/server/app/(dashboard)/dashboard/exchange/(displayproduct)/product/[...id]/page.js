(() => {
var exports = {};
exports.id = 4985;
exports.ids = [4985];
exports.modules = {

/***/ 55752:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom-experimental/server-rendering-stub");

/***/ }),

/***/ 17640:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental");

/***/ }),

/***/ 76931:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-experimental/jsx-runtime");

/***/ }),

/***/ 67597:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack-experimental/client");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 63784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'dashboard',
        {
        children: [
        'exchange',
        {
        children: [
        '(displayproduct)',
        {
        children: [
        'product',
        {
        children: [
        '[...id]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 66617)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\exchange\\(displayproduct)\\product\\[...id]\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 53633)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\exchange\\(displayproduct)\\product\\[...id]\\layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 42981)), "C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\(dashboard)\\dashboard\\exchange\\(displayproduct)\\product\\[...id]\\page.tsx"];
    
    const originalPathname = "/(dashboard)/dashboard/exchange/(displayproduct)/product/[...id]/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 23275:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 63912, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22026));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 86268))

/***/ }),

/***/ 34914:
/***/ (() => {



/***/ }),

/***/ 22026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Dashboard_BuyDisplay)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./components/UI/SvgIcons/CheckedSvg.tsx
var CheckedSvg = __webpack_require__(81775);
// EXTERNAL MODULE: ./components/UI/Toggle.tsx
var Toggle = __webpack_require__(78650);
// EXTERNAL MODULE: ./components/UI/SvgIcons/LockSvg.tsx
var LockSvg = __webpack_require__(63940);
;// CONCATENATED MODULE: ./components/Form/FormComponents/BasicSelect.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
const BasicSelect = ({ options, handleSelect })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                htmlFor: "quantity",
                className: "block mb-2  font-light text-white",
                children: "Quantity"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                id: "countries",
                onChange: (e)=>{
                    handleSelect(e);
                },
                className: "bg-[#23262F] border text-white text-center text-sm rounded-lg  block w-full p-2.5 ",
                children: options.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                        value: option,
                        children: option
                    }, option))
            })
        ]
    });
};
/* harmony default export */ const FormComponents_BasicSelect = (BasicSelect);

;// CONCATENATED MODULE: ./components/Dashboard/BuyDisplay.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const BuyDisplay = ({ canCustom, id, accessToken, price, pageType, pid })=>{
    const router = (0,navigation.useRouter)();
    const [quantity, setQuantity] = (0,react_experimental_.useState)("1");
    const handleQuantity = (e)=>{
        const value = e.target.value;
        setQuantity(value);
    };
    const paths = (0,navigation.usePathname)().split("/");
    const pathname = paths[paths.length - 1];
    const buyHandler = async ()=>{
        const data = {
            quantity: quantity,
            product_id: pid,
            type: "buyorder"
        };
        const config = {
            method: "POST",
            maxBodyLength: Infinity,
            url: "/api/order",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${accessToken}`
            },
            data: JSON.stringify(data)
        };
        try {
            const response = await (0,axios/* default */.Z)(config);
            console.log(response.data);
            router.push(`/dashboard/transaction/order/${pathname}?pid=${response.data.data.id}`);
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            " ",
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-xl",
                        children: "Buy in Custom Amount"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Toggle/* default */.Z, {
                        isChecked: Number(canCustom) === 0 ? false : true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "border-t border-gray-600 "
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-6 py-6 border-2 border-gray-600 rounded-lg space-y-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full  flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Get all knowledge how to deal in gift cards"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full  flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Best trading techniques"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Increase Profits"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-12 py-8 bg-[#23262F] rounded-xl  text-center space-y-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: pageType === "buy" && /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_BasicSelect, {
                            options: [
                                1,
                                2,
                                3,
                                4,
                                5,
                                6,
                                7,
                                8,
                                9,
                                10
                            ],
                            handleSelect: handleQuantity
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-light",
                                children: "You have to pay"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-3xl font-semibold text-[#587BF2]",
                                children: [
                                    "$",
                                    Number(quantity) * Number(price)
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-x-3 items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "p-3 rounded-full border border-gray-600",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(LockSvg/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: buyHandler,
                        type: "button",
                        className: "w-full rounded-xl bg-[#587BF2] relative text-sm px-2 py-2  flex justify-center items-center lg:py-3 lg:text-base hover:bg-[#4366d7]",
                        children: "Buy Gift Card"
                    })
                ]
            }),
            " "
        ]
    });
};
/* harmony default export */ const Dashboard_BuyDisplay = (BuyDisplay);


/***/ }),

/***/ 86268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Dashboard_SellDisplay)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: external "next/dist/compiled/react-experimental"
var react_experimental_ = __webpack_require__(17640);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./components/UI/SvgIcons/CheckedSvg.tsx
var CheckedSvg = __webpack_require__(81775);
// EXTERNAL MODULE: ./components/UI/Toggle.tsx
var Toggle = __webpack_require__(78650);
;// CONCATENATED MODULE: ./components/Form/FormComponents/BuyAmountInput.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
const BuyAmountInput = ({ isFixedPrice, handleAmount, amount })=>{
    // const [value, setValue] = useState("");
    // const handleValue = (e: any) => {
    //   setValue(e.target.value);
    // };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-12 border border-gray-600 rounded-lg flex justify-center items-center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-3xl ml-12",
                children: "$"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "number",
                value: amount,
                className: "bg-transparent text-white text-3xl w-28 outline-none",
                onChange: handleAmount
            })
        ]
    });
};
/* harmony default export */ const FormComponents_BuyAmountInput = (BuyAmountInput);

// EXTERNAL MODULE: ./components/UI/SvgIcons/LockSvg.tsx
var LockSvg = __webpack_require__(63940);
;// CONCATENATED MODULE: ./components/Dashboard/SellDisplay.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const SellDisplay = ({ canCustom, id, accessToken, price, pageType, pid })=>{
    const router = (0,navigation.useRouter)();
    const paths = (0,navigation.usePathname)().split("/");
    const pathname = paths[paths.length - 1];
    const sellHandler = async (amount)=>{
        const data = {
            price: amount,
            product_id: pid,
            type: "sellorder"
        };
        const config = {
            method: "POST",
            maxBodyLength: Infinity,
            url: "/api/order",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                Authorization: `Bearer ${accessToken}`
            },
            data: JSON.stringify(data)
        };
        try {
            const response = await (0,axios/* default */.Z)(config);
            console.log(response.data);
            router.push(`/dashboard/transaction/order/${pathname}?pid=${response.data.data.id}`);
        } catch (error) {
            console.log(error);
        }
    };
    const [amount, setAmount] = (0,react_experimental_.useState)("");
    const handleAmount = (e)=>{
        const val = e.target.value;
        setAmount(val);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-xl",
                        children: "Buy in Custom Amount"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Toggle/* default */.Z, {
                        isChecked: Number(canCustom) === 0 ? false : true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                className: "border-t border-gray-600 "
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-6 py-6 border-2 border-gray-600 rounded-lg space-y-2",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full  flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Get all knowledge how to deal in gift cards"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full  flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Best trading techniques"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex gap-x-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CheckedSvg/* default */.Z, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Increase Profits"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-12 py-8 bg-[#23262F] rounded-xl  text-center space-y-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(FormComponents_BuyAmountInput, {
                            isFixedPrice: Number(canCustom) === 0 ? false : true,
                            handleAmount: handleAmount,
                            amount: amount
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-light",
                                children: "You have to pay"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-3xl font-semibold text-[#587BF2]",
                                children: [
                                    "$",
                                    amount
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex gap-x-3 items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "p-3 rounded-full border border-gray-600",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(LockSvg/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>{
                            sellHandler(amount);
                        },
                        type: "button",
                        className: "w-full rounded-xl bg-[#587BF2] relative text-sm px-2 py-2  flex justify-center items-center lg:py-3 lg:text-base hover:bg-[#4366d7]",
                        children: "Sell Gift Card"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Dashboard_SellDisplay = (SellDisplay);


/***/ }),

/***/ 81775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const CheckedSvg = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 20,
        height: 20,
        viewBox: "0 0 20 20",
        fill: "none",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M9.99935 18.3332C14.6017 18.3332 18.3327 14.6022 18.3327 9.99984C18.3327 5.39746 14.6017 1.6665 9.99935 1.6665C5.39698 1.6665 1.66602 5.39746 1.66602 9.99984C1.66602 14.6022 5.39698 18.3332 9.99935 18.3332ZM14.8731 8.20694C15.2636 7.81642 15.2636 7.18325 14.8731 6.79273C14.4826 6.40221 13.8494 6.40221 13.4589 6.79273L9.16602 11.0856L7.37312 9.29273C6.9826 8.90221 6.34943 8.90221 5.95891 9.29273C5.56838 9.68325 5.56838 10.3164 5.95891 10.7069L8.45891 13.2069C8.84943 13.5975 9.4826 13.5975 9.87312 13.2069L14.8731 8.20694Z",
            fill: "#45B36B"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckedSvg);


/***/ }),

/***/ 63940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17640);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const LockSvg = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        viewBox: "0 0 24 24",
        fill: "none",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M12 11C10.2274 11 8.64844 11.0646 7.35838 11.1466C6.13471 11.2243 5.19379 12.158 5.10597 13.373C5.0435 14.2373 5 15.1481 5 16C5 16.8519 5.0435 17.7627 5.10597 18.627C5.19379 19.842 6.13471 20.7757 7.35838 20.8534C8.64844 20.9354 10.2274 21 12 21C13.7726 21 15.3516 20.9354 16.6416 20.8534C17.8653 20.7757 18.8062 19.842 18.894 18.627C18.9565 17.7627 19 16.8519 19 16C19 15.1481 18.9565 14.2373 18.894 13.373C18.8062 12.158 17.8653 11.2243 16.6416 11.1466C15.3516 11.0646 13.7726 11 12 11ZM7.2315 9.15059C5.01376 9.29156 3.27137 11.0124 3.11117 13.2288C3.04652 14.1234 3 15.085 3 16C3 16.915 3.04652 17.8766 3.11118 18.7712C3.27137 20.9876 5.01376 22.7084 7.23151 22.8494C8.55778 22.9337 10.1795 23 12 23C13.8205 23 15.4422 22.9337 16.7685 22.8494C18.9862 22.7084 20.7286 20.9876 20.8888 18.7712C20.9535 17.8766 21 16.915 21 16C21 15.085 20.9535 14.1234 20.8888 13.2288C20.7286 11.0124 18.9862 9.29156 16.7685 9.15059C15.4422 9.06629 13.8205 9 12 9C10.1795 9 8.55778 9.06629 7.2315 9.15059Z",
                fill: "#777E91"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M13 16.7324C13.5978 16.3866 14 15.7403 14 15C14 13.8954 13.1046 13 12 13C10.8954 13 10 13.8954 10 15C10 15.7403 10.4022 16.3866 11 16.7324V18C11 18.5523 11.4477 19 12 19C12.5523 19 13 18.5523 13 18V16.7324Z",
                fill: "#777E91"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M7 6C7 3.23858 9.23858 1 12 1C14.7614 1 17 3.23858 17 6V10C17 10.5523 16.5523 11 16 11C15.4477 11 15 10.5523 15 10V6C15 4.34315 13.6569 3 12 3C10.3431 3 9 4.34315 9 6V10C9 10.5523 8.55228 11 8 11C7.44772 11 7 10.5523 7 10V6Z",
                fill: "#777E91"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LockSvg);


/***/ }),

/***/ 78650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Toggle = ({ isChecked })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
            className: "relative inline-flex items-center cursor-pointer",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "checkbox",
                    value: "",
                    className: "sr-only peer",
                    checked: isChecked
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Toggle);


/***/ }),

/***/ 53633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76931);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35465);


const layout = ({ children })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full pb-32 lg:pb-10 h-screen bg-secondary",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (layout);


/***/ }),

/***/ 66617:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react-experimental/jsx-runtime"
var jsx_runtime_ = __webpack_require__(76931);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react-experimental/react.shared-subset.js
var react_shared_subset = __webpack_require__(35465);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(63919);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/Dashboard/BuyDisplay.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Dashboard\BuyDisplay.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const BuyDisplay = (__default__);
;// CONCATENATED MODULE: ./components/Dashboard/SellDisplay.tsx

const SellDisplay_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\ZION-BA GH\Desktop\fawaz\apk-gifty\components\Dashboard\SellDisplay.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: SellDisplay_esModule, $$typeof: SellDisplay_$$typeof } = SellDisplay_proxy;
const SellDisplay_default_ = SellDisplay_proxy.default;


/* harmony default export */ const SellDisplay = (SellDisplay_default_);
;// CONCATENATED MODULE: ./components/Dashboard/BuyInstructions.tsx


const BuyInstructions = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "text-base text-gray-400 py-4",
                children: "Before Proceeding to buy/sell your Gift Card or Other Payment methods, Follow These Intructions;"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                className: "list-decimal space-y-4 text-gray-400 lg:pl-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Remember every trade that occurs on our platform attracts a fee of 1% on every amount. All trades less than $100 will attract a $1 fee on it."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Before you proceed Kindly make sure you’ve read through our Trade Guidelines before proceeding."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "The card or the code of your order will be uploaded in the chat section of this trade. Make sure to use the card within the timeframe provided for you."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Dashboard_BuyInstructions = (BuyInstructions);

;// CONCATENATED MODULE: ./components/Dashboard/SellInstructions.tsx


const SellInstructions = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                className: "list-decimal space-y-4 text-gray-400 lg:pl-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Before sending us your gift card, we kindly request you to ensure that you have confirmed or verified its balance."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Please only proceed to send the gift card once you have ascertained that the balance is intact. Most gift cards can be checked and verified, with the exception of Amazon"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "For cards like Onevanilla, refrain from checking the balance on balance.VanillaGift.com, as it may cause harm to the card and render it invalid. Instead, contact the Onevanilla call center to verify if the card is active with the correct balance before sending it to us."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: 'To verify the balance of an iTunes gift card, simply perform a quick Google search using the phrase "iTunes gift card balance check." This will lead you to the direct link for verifying the card\'s balance on the Apple website.'
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "For cards from retailers like Walmart, BestBuy, and others, you can verify their balances on their respective websites. Please make sure to do this before proceeding with your gift card submission."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "Once you have confirmed the balance, you can proceed to send us your gift card. Typically, we aim to process payments within 30 minutes to 1 hour after verification and usage of your gift card. However, please note that the timeframe may vary if there is a high volume of Sell Orders on our platform."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: "If your card's balance is valid for usage, you can rest assured that everything will proceed smoothly. Your card will be utilized, and payment will be made to your account as expected."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Upon verifying the card's balance and completing the payment, our administration will automatically close the trade."
            })
        ]
    });
};
/* harmony default export */ const Dashboard_SellInstructions = (SellInstructions);

;// CONCATENATED MODULE: ./app/(dashboard)/dashboard/exchange/(displayproduct)/product/[...id]/page.tsx








const ProductDisplay = ({ searchParams, params })=>{
    const cookieStore = (0,headers.cookies)();
    const accessToken = cookieStore.get("access")?.value;
    const pageType = params.id[0];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex w-full     ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full flex  flex-col gap-y-12  justify-between text-white py-10 bg-secondary  lg:flex-row  lg:gap-y-0  ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex lg:flex-[65%]  flex-col gap-y-6 px-12",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-x-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "px-3 py-1 bg-red-400 rounded-lg text-sm",
                                    children: "Gift Cards"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "px-3 py-1 bg-green-400 rounded-lg text-sm",
                                    children: "Popular"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    className: "text-2xl font-semibold",
                                    children: "Order Instructions"
                                }),
                                pageType === "buy" && /*#__PURE__*/ jsx_runtime_.jsx(Dashboard_BuyInstructions, {}),
                                pageType == "sell" && /*#__PURE__*/ jsx_runtime_.jsx(Dashboard_SellInstructions, {})
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: searchParams.image_url,
                                alt: "gifts image",
                                width: 650,
                                height: 300,
                                className: "rounded-lg"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "lg:flex-[35%] pb-32 flex-shrink flex flex-col gap-y-8 px-12 mb-16 lg:mb-0 lg:pb-2 ",
                    children: [
                        pageType === "buy" && /*#__PURE__*/ jsx_runtime_.jsx(BuyDisplay, {
                            canCustom: searchParams.can_custom,
                            accessToken: accessToken,
                            id: searchParams.id,
                            price: searchParams.price,
                            pageType: pageType,
                            pid: searchParams.pid
                        }),
                        pageType === "sell" && /*#__PURE__*/ jsx_runtime_.jsx(SellDisplay, {
                            canCustom: searchParams.can_custom,
                            accessToken: accessToken,
                            id: searchParams.id,
                            price: searchParams.price,
                            pageType: pageType,
                            pid: searchParams.pid
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const page = (ProductDisplay);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,8511,9967,993,248,5522,1635,8732], () => (__webpack_exec__(63784)));
module.exports = __webpack_exports__;

})();