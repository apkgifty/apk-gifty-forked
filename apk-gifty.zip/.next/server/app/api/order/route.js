"use strict";
(() => {
var exports = {};
exports.id = 9485;
exports.ids = [9485];
exports.modules = {

/***/ 39491:
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 32189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  headerHooks: () => (/* binding */ headerHooks),
  originalPathname: () => (/* binding */ originalPathname),
  requestAsyncStorage: () => (/* binding */ requestAsyncStorage),
  routeModule: () => (/* binding */ routeModule),
  serverHooks: () => (/* binding */ serverHooks),
  staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),
  staticGenerationBailout: () => (/* binding */ staticGenerationBailout)
});

// NAMESPACE OBJECT: ./app/api/order/route.ts
var route_namespaceObject = {};
__webpack_require__.r(route_namespaceObject);
__webpack_require__.d(route_namespaceObject, {
  GET: () => (GET),
  POST: () => (POST)
});

// EXTERNAL MODULE: ./node_modules/next/dist/server/node-polyfill-headers.js
var node_polyfill_headers = __webpack_require__(35387);
// EXTERNAL MODULE: ./node_modules/next/dist/server/future/route-modules/app-route/module.js
var app_route_module = __webpack_require__(29267);
var module_default = /*#__PURE__*/__webpack_require__.n(app_route_module);
// EXTERNAL MODULE: ./utils/axios.ts
var axios = __webpack_require__(61496);
// EXTERNAL MODULE: ./node_modules/next/dist/server/web/exports/next-response.js
var next_response = __webpack_require__(32413);
;// CONCATENATED MODULE: ./app/api/order/route.ts
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
// import axios from "axios";


async function POST(req, res) {
    const body = await req.json();
    let data = JSON.stringify({
        ...body
    });
    let config = {
        method: "POST",
        maxBodyLength: Infinity,
        url: `https://backend.apkxchange.com/api/product/${body.type}`,
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json"
        },
        data: data
    };
    try {
        const response = await (0,axios/* default */.Z)(config);
        console.log(response);
        return next_response/* default */.Z.json(response.data);
    } catch (error) {
        console.log(error);
        return new Response(JSON.stringify(error.response.data), {
            status: error.response.status,
            headers: error.response.header
        });
    }
}
async function GET(req, res) {
    const body = await req.json();
    const { id } = body;
    console.log(id);
    let config = {
        method: "GET",
        maxBodyLength: Infinity,
        url: `/api/order/${id}`,
        headers: {
            "Content-Type": "application/json",
            Accept: "application/json"
        }
    };
    try {
        const response = await (0,axios/* default */.Z)(config);
        console.log(response);
        return next_response/* default */.Z.json(response.data);
    } catch (error) {
        console.log(error);
        return new Response(JSON.stringify(error.response.data), {
            status: error.response.status,
            headers: error.response.header
        });
    }
}

;// CONCATENATED MODULE: ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?page=%2Fapi%2Forder%2Froute&name=app%2Fapi%2Forder%2Froute&pagePath=private-next-app-dir%2Fapi%2Forder%2Froute.ts&appDir=C%3A%5CUsers%5CZION-BA%20GH%5CDesktop%5Cfawaz%5Capk-gifty%5Capp&appPaths=%2Fapi%2Forder%2Froute&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!

    

    

    

    const options = {"definition":{"kind":"APP_ROUTE","page":"/api/order/route","pathname":"/api/order","filename":"route","bundlePath":"app/api/order/route"},"resolvedPagePath":"C:\\Users\\ZION-BA GH\\Desktop\\fawaz\\apk-gifty\\app\\api\\order\\route.ts","nextConfigOutput":""}
    const routeModule = new (module_default())({
      ...options,
      userland: route_namespaceObject,
    })

    // Pull out the exports that we need to expose from the module. This should
    // be eliminated when we've moved the other routes to the new format. These
    // are used to hook into the route.
    const {
      requestAsyncStorage,
      staticGenerationAsyncStorage,
      serverHooks,
      headerHooks,
      staticGenerationBailout
    } = routeModule

    const originalPathname = "/api/order/route"

    

/***/ }),

/***/ 32413:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
// This file is for modularized imports for next/server to get fully-treeshaking.

__webpack_unused_export__ = ({
    value: true
});
Object.defineProperty(exports, "Z", ({
    enumerable: true,
    get: function() {
        return _response.NextResponse;
    }
}));
const _response = __webpack_require__(72917); //# sourceMappingURL=next-response.js.map


/***/ }),

/***/ 63919:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


module.exports = __webpack_require__(83851);


/***/ }),

/***/ 61496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66558);
/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(63919);
/* harmony import */ var next_headers__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_headers__WEBPACK_IMPORTED_MODULE_0__);


const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.create({
    baseURL: "https://backend.apkxchange.com/api"
});
axiosInstance.interceptors.request.use((config)=>{
    const cookieStore = (0,next_headers__WEBPACK_IMPORTED_MODULE_0__.cookies)();
    const accessToken = cookieStore.get("access")?.value;
    if (accessToken) {
        config.headers["Authorization"] = `Bearer ${accessToken}`;
    }
    return config;
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosInstance);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,9967,6558,4625], () => (__webpack_exec__(32189)));
module.exports = __webpack_exports__;

})();