interface MainNav {
  title: string;
  link: string;
}

export type { MainNav };
