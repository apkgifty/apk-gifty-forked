interface Props {
  size?: "small" | "medium" | "large";
}

const NewsSvg: React.FC<Props> = ({ size }) => {
  let iconSize;

  switch (size) {
    case "small":
      iconSize = "w-5 h-5";
      break;
    case "medium":
      iconSize = "w-8 h-8";
      break;
    case "large":
      iconSize = "w-12 h-12";
      break;
  }
  return (
    <svg
      className={`${size ? iconSize : "w-5 h-5"}`}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g id="News-Icon" clipPath="url(#clip0_101_4106)">
        <path
          id="Vector"
          d="M19 22H5C4.20435 22 3.44129 21.6839 2.87868 21.1213C2.31607 20.5587 2 19.7956 2 19V3C2 2.73478 2.10536 2.48043 2.29289 2.29289C2.48043 2.10536 2.73478 2 3 2H17C17.2652 2 17.5196 2.10536 17.7071 2.29289C17.8946 2.48043 18 2.73478 18 3V15H22V19C22 19.7956 21.6839 20.5587 21.1213 21.1213C20.5587 21.6839 19.7956 22 19 22ZM18 17V19C18 19.2652 18.1054 19.5196 18.2929 19.7071C18.4804 19.8946 18.7348 20 19 20C19.2652 20 19.5196 19.8946 19.7071 19.7071C19.8946 19.5196 20 19.2652 20 19V17H18ZM16 20V4H4V19C4 19.2652 4.10536 19.5196 4.29289 19.7071C4.48043 19.8946 4.73478 20 5 20H16ZM6 7H14V9H6V7ZM6 11H14V13H6V11ZM6 15H11V17H6V15Z"
          fill="#F0F4F7"
        />
      </g>
      <defs>
        <clipPath id="clip0_101_4106">
          <rect width={24} height={24} fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};

export default NewsSvg;
