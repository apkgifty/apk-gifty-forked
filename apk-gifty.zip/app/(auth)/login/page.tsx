import LoginForm from "@/components/Form/LoginForm";

const LoginPage = () => {
  return (
    <>
      <LoginForm />
    </>
  );
};

export default LoginPage;
