import ConfirmationForm from "@/components/Form/ConfirmationForm";

const ConfirmationPage = () => {
  return (
    <>
      <ConfirmationForm />
    </>
  );
};

export default ConfirmationPage;
