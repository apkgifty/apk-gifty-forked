import SignupForm from "@/components/Form/SignupForm";

const SignupPage = () => {
  return (
    <>
      <SignupForm />
    </>
  );
};

export default SignupPage;
