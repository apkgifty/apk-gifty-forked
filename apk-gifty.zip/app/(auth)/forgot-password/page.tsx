import ForgotPasswordForm from "@/components/Form/ForgotPasswordForm";
import React from "react";

const ForgotPasswordPage = () => {
  return (
    <>
      <ForgotPasswordForm />
    </>
  );
};

export default ForgotPasswordPage;
