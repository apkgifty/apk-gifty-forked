import PasswordResetForm from "@/components/Form/PasswordResetForm";
import React from "react";

const PasswordReset = () => {
  return (
    <>
      <PasswordResetForm />
    </>
  );
};

export default PasswordReset;
