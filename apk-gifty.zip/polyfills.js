"use client";

import "core-js/features/string/replace-all";
